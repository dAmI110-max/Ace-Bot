class GroupHandler {
    constructor(aceBot) {
        this.ace = aceBot;
    }

    async handleParticipants(update) {
        const { id, participants, action } = update;
        
        if (action === 'add') {
            for (const participant of participants) {
                await this.handleNewParticipant(id, participant);
            }
        }
    }

    async handleNewParticipant(groupJid, participantJid) {
        if (process.env.WELCOME_MESSAGE_ENABLED === 'true') {
            const welcomeText = `
🎉 *Welcome to the Group!* 🎉

👋 Hello @${participantJid.split('@')[0]}!

⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 welcomes you!

📢 *Join our official channel:*
${process.env.WHATSAPP_CHANNEL_LINK}

🤖 *Bot Commands:*
• !menu - Show menu
• !help - Get help
• !rules - Group rules

Enjoy your stay! ⛧
            `;
            
            await this.ace.sendACEMessage(groupJid, welcomeText);
            
            setTimeout(async () => {
                await this.ace.sendChannelPromotion(groupJid);
            }, 2000);
        }
    }
}

module.exports = GroupHandler;
