class MessageHandler {
    constructor(aceBot) {
        this.ace = aceBot;
    }

    async handle(m) {
        if (!m.messages || m.messages.length === 0) return;
        
        const message = m.messages[0];
        if (!message.message) return;
        
        const userJid = message.key.participant || message.key.remoteJid;
        const isGroup = message.key.remoteJid.endsWith('@g.us');
        const groupJid = isGroup ? message.key.remoteJid : null;
        
        if (message.key.fromMe) return;

        let isAdmin = false;
        if (isGroup) {
            try {
                const metadata = await this.ace.sock.groupMetadata(groupJid);
                const participant = metadata.participants.find(p => p.id === userJid);
                isAdmin = participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
            } catch (err) {
                console.log('Metadata error:', err.message);
            }
        }

        if (isGroup) {
            this.ace.funAnti?.updateActivity(userJid, groupJid);
            this.ace.funAnti?.antiSleep(groupJid);
        }

        if (isGroup) {
            await this.ace.antiLink.check(message.message, groupJid, userJid, isAdmin);
            const isSpam = await this.ace.antiSpam.check(userJid, groupJid, isAdmin);
            if (isSpam) return;
            
            await this.ace.funAnti?.checkDry(userJid, groupJid, message.message);
            await this.ace.funAnti?.checkFlex(userJid, groupJid, message.message);
            await this.ace.funAnti?.checkRizz(userJid, groupJid, message.message);
        }

        if (!isGroup) {
            await this.ace.autoReply.handle(message.message, userJid, null);
        }

        await this.ace.commandHandler.handle(message, userJid, groupJid, isAdmin);
    }
}

module.exports = MessageHandler;
