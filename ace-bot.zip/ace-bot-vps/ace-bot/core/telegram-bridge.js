const TelegramBot = require('node-telegram-bot-api');
const QRCode = require('qrcode');

class TelegramBridge {
    constructor(aceBot) {
        this.ace = aceBot;
        this.token = process.env.TELEGRAM_TOKEN;
        this.adminId = process.env.ADMIN_ID;
        this.bot = new TelegramBot(this.token, { polling: true });
        this.verifiedUsers = new Set();
    }

    init() {
        this.setupCommands();
        console.log('📱 Telegram Bridge Active');
    }

    setupCommands() {
        this.bot.onText(/\/start/, async (msg) => {
            await this.handleStart(msg);
        });

        this.bot.on('callback_query', async (query) => {
            await this.handleCallback(query);
        });

        this.bot.onText(/\/stats/, async (msg) => {
            if (msg.from.id.toString() !== this.adminId) return;
            await this.sendStats(msg.chat.id);
        });

        this.bot.onText(/\/menu/, async (msg) => {
            if (this.verifiedUsers.has(msg.from.id)) {
                this.showMainMenu(msg.chat.id, msg.from.first_name);
            }
        });
    }

    async handleStart(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const name = msg.from.first_name;

        if (this.verifiedUsers.has(userId)) {
            this.showMainMenu(chatId, name);
            return;
        }

        const welcome = `
╔════════════════════════════════════╗
║     ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】      ║
║         𝐀𝐂𝐄 𝐁𝐎𝐓 𝐒𝐘𝐒𝐓𝐄𝐌          ║
╚════════════════════════════════════╝

👋 Welcome, ${name}!

🔐 WhatsApp Pairing Service
   by ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】

⚠️ Join @Cybervault012 to continue
        `;

        this.bot.sendMessage(chatId, welcome, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "📢 Join Group", url: "https://t.me/Cybervault012" },
                        { text: "✓ Verify", callback_data: "verify" }
                    ]
                ]
            }
        });
    }

    async handleCallback(query) {
        const chatId = query.message.chat.id;
        const userId = query.from.id;
        const data = query.data;

        this.bot.answerCallbackQuery(query.id);

        if (data === 'verify') {
            this.verifiedUsers.add(userId);
            this.bot.editMessageText('✅ Verified!', {
                chat_id: chatId,
                message_id: query.message.message_id
            });
            this.showMainMenu(chatId, query.from.first_name);
        }
        else if (data === 'pairing_code') {
            this.requestPhoneNumber(chatId, userId);
        }
        else if (data === 'qr_code') {
            this.bot.sendMessage(chatId, '⏳ Connect via WhatsApp first...');
        }
        else if (data === 'main_menu') {
            this.showMainMenu(chatId, query.from.first_name);
        }
    }

    showMainMenu(chatId, name) {
        const menu = `⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 𝐌𝐄𝐍𝐔\n\nHello ${name}! 👋`;
        
        this.bot.sendMessage(chatId, menu, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔢 Pairing Code", callback_data: "pairing_code" },
                        { text: "📷 QR Code", callback_data: "qr_code" }
                    ],
                    [
                        { text: "📢 Community", url: "https://t.me/Cybervault012" },
                        { text: "❓ Help", callback_data: "help" }
                    ]
                ]
            }
        });
    }

    requestPhoneNumber(chatId, userId) {
        this.bot.sendMessage(chatId, 
            "📱 *Enter WhatsApp number:*\nFormat: `254712345678`",
            { parse_mode: 'Markdown', reply_markup: { force_reply: true } }
        );
        
        this.bot.once('message', async (msg) => {
            if (msg.chat.id === chatId && msg.text && !msg.text.startsWith('/')) {
                const number = msg.text.replace(/\D/g, '');
                
                this.bot.sendMessage(chatId, "⏳ Generating pairing code...");
                
                try {
                    const code = await this.ace.telegramGetPairCode(userId.toString(), number);
                    
                    this.bot.sendMessage(chatId,
                        `🔐 *PAIRING CODE*\n\n\`${code}\`\n\n⚡ Enter immediately! (30s)`,
                        { parse_mode: 'Markdown' }
                    );
                } catch (err) {
                    this.bot.sendMessage(chatId, `❌ Error: ${err.message}`);
                }
            }
        });
    }

    async sendQR(qrString) {
        try {
            const buffer = await QRCode.toBuffer(qrString);
            this.bot.sendPhoto(this.adminId, buffer, {
                caption: '📷 *WhatsApp QR Code*\nScan to connect ACE♡ Bot',
                parse_mode: 'Markdown'
            });
        } catch (err) {
            console.error('QR send failed:', err);
        }
    }

    sendNotification(text) {
        this.bot.sendMessage(this.adminId, text, { parse_mode: 'Markdown' });
    }

    async sendStats(chatId) {
        const stats = `
📊 *ACE♡ BOT STATS*

⏰ Uptime: ${Math.floor((Date.now() - this.ace.sessionStartTime) / 1000)}s
👥 Groups: ${this.ace.groupsData.size}
🤖 Status: Online
        `;
        this.bot.sendMessage(chatId, stats, { parse_mode: 'Markdown' });
    }
}

module.exports = TelegramBridge;
