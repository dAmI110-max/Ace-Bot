const TelegramBot = require('node-telegram-bot-api');
const { getPairCode, getQRCode } = require('./ace');

const TOKEN = '8619246270:AAH6y8XIrgpAWGZxiOiv-aovMlQYb4jJFWw';
const bot = new TelegramBot(TOKEN, { polling: true });

const ADMIN_ID = '6828904193';
const WHATSAPP_GROUP_LINK = 'https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo';
const WHATSAPP_CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i';

const BANK_DETAILS = {
    account: '3229976040',
    bank: 'First Bank',
    name: 'Bhadmus Oluwadamilare Emmanuel'
};

const SOCIAL_LINKS = {
    youtube: 'https://youtube.com/@davesbrown-mp2nl?si=ZPQViEETJkJLAG_J',
    instagram: 'https://www.instagram.com/aceprofile001?igsh=cjM4am1hZzQycjhp',
    whatsapp: 'https://wa.me/2349040464374'
};

const verifiedUsers = new Set();
const activeSessions = new Map();
const userStates = new Map();

function isAdmin(userId) {
    return userId.toString() === ADMIN_ID;
}

async function checkMembership(userId) {
    try {
        const chatMember = await bot.getChatMember('@Cybervault012', userId);
        return ['member', 'administrator', 'creator'].includes(chatMember.status);
    } catch (err) {
        return false;
    }
}

function getWelcomeMessage(userName) {
    return `
╔════════════════════════════════════╗
║     ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】      ║
║         𝐀𝐂𝐄 𝐁𝐎𝐓 𝐒𝐘𝐒𝐓𝐄𝐌          ║
╚════════════════════════════════════╝

👋 Welcome, ${userName}!

🔐 WhatsApp Pairing Service
   by ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】

⚠️ Join @Cybervault012 to continue
    `;
}

bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const userName = msg.from.first_name || 'User';

    if (verifiedUsers.has(userId)) {
        showMainMenu(chatId, userName, userId);
        return;
    }

    const welcomeText = getWelcomeMessage(userName);
    
    bot.sendMessage(chatId, welcomeText, {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "📢 Join Telegram Group", url: "https://t.me/Cybervault012" },
                    { text: "📲 Join WhatsApp Channel", url: WHATSAPP_CHANNEL_LINK }
                ],
                [
                    { text: "▶️ YouTube Channel", url: SOCIAL_LINKS.youtube },
                    { text: "📸 Instagram", url: SOCIAL_LINKS.instagram }
                ],
                [
                    { text: "💬 WhatsApp Support", url: SOCIAL_LINKS.whatsapp },
                    { text: "✓ Verify Membership", callback_data: "verify_membership" }
                ],
                [
                    { text: "❓ Help & Support", callback_data: "help" }
                ]
            ]
        }
    });
});

bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const userId = query.from.id;
    const userName = query.from.first_name || 'User';
    const data = query.data;

    bot.answerCallbackQuery(query.id);

    if (data === 'verify_membership') {
        const isMember = await checkMembership(userId);
        
        if (isMember) {
            verifiedUsers.add(userId);
            bot.editMessageText(
                `✅ *VERIFICATION SUCCESSFUL!*\n\nWelcome, ${userName}! 🎉`,
                {
                    chat_id: chatId,
                    message_id: query.message.message_id,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: "🚀 Launch Bot", callback_data: "launch_bot" }]]
                    }
                }
            );
        } else {
            bot.editMessageText(
                `❌ *VERIFICATION FAILED*\n\nJoin @Cybervault012 first!`,
                {
                    chat_id: chatId,
                    message_id: query.message.message_id,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: "📢 Join Group", url: "https://t.me/Cybervault012" },
                            { text: "🔄 Try Again", callback_data: "verify_membership" }
                        ]]
                    }
                }
            );
        }
    }

    else if (data === 'launch_bot' || data === 'main_menu') {
        showMainMenu(chatId, userName, userId);
    }

    else if (data === 'pairing_code') {
        requestPhoneNumber(chatId, userId);
    }

    else if (data === 'qr_code') {
        generateQRCode(chatId, userId);
    }

    else if (data === 'social_links') {
        showSocialLinks(chatId);
    }

    else if (data === 'premium') {
        showPremium(chatId);
    }

    else if (data === 'help') {
        showHelp(chatId);
    }

    else if (data === 'admin_panel') {
        showAdminPanel(chatId);
    }
});

function showMainMenu(chatId, userName, userId) {
    const isUserAdmin = isAdmin(userId);
    
    let buttons = [
        [
            { text: "🔢 Pairing Code", callback_data: "pairing_code" },
            { text: "📷 QR Code", callback_data: "qr_code" }
        ],
        [
            { text: "📢 Join Community", url: "https://t.me/Cybervault012" },
            { text: "🌐 Social Links", callback_data: "social_links" }
        ],
        [
            { text: "⭐ Premium", callback_data: "premium" },
            { text: "❓ Help", callback_data: "help" }
        ]
    ];

    if (isUserAdmin) {
        buttons.push([{ text: "🔐 Admin Panel", callback_data: "admin_panel" }]);
    }

    bot.sendMessage(chatId, 
        `⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 𝐁𝐎𝐓 𝐌𝐄𝐍𝐔\n\nHello ${userName}! 👋`, 
        {
            parse_mode: 'Markdown',
            reply_markup: { inline_keyboard: buttons }
        }
    );
}

function showSocialLinks(chatId) {
    bot.sendMessage(chatId,
        `🌐 *FOLLOW ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】*`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "▶️ YouTube", url: SOCIAL_LINKS.youtube },
                        { text: "📸 Instagram", url: SOCIAL_LINKS.instagram }
                    ],
                    [
                        { text: "📢 Telegram Group", url: "https://t.me/Cybervault012" },
                        { text: "💬 WhatsApp Support", url: SOCIAL_LINKS.whatsapp }
                    ],
                    [{ text: "🏠 Main Menu", callback_data: "main_menu" }]
                ]
            }
        }
    );
}

function showPremium(chatId) {
    bot.sendMessage(chatId,
        `⭐ *UPGRADE TO PREMIUM*\n\n` +
        `Benefits:\n✅ Unlimited pairing codes\n✅ Priority support\n✅ No QR expiration\n✅ Multiple devices\n\n` +
        `*Payment:*\n` +
        `Bank: ${BANK_DETAILS.bank}\n` +
        `Account: \`${BANK_DETAILS.account}\`\n` +
        `Name: ${BANK_DETAILS.name}\n\n` +
        `Send screenshot after payment:`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "💬 Send Proof", url: SOCIAL_LINKS.whatsapp }],
                    [{ text: "🏠 Main Menu", callback_data: "main_menu" }]
                ]
            }
        }
    );
}

function showHelp(chatId) {
    bot.sendMessage(chatId,
        `❓ *ACE BOT COMMANDS*\n\n` +
        `*/start* - Welcome & verification\n` +
        `*/menu* - Main menu\n` +
        `*/help* - This message\n\n` +
        `*Creator:* ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】\n` +
        `*Support:* +2349040464374`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "💬 WhatsApp Support", url: SOCIAL_LINKS.whatsapp }],
                    [{ text: "🏠 Main Menu", callback_data: "main_menu" }]
                ]
            }
        }
    );
}

function showAdminPanel(chatId) {
    bot.sendMessage(chatId,
        `🔐 *ADMIN PANEL*\n` +
        `⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 ONLY\n\n` +
        `Users: ${verifiedUsers.size}\n` +
        `Sessions: ${activeSessions.size}`,
        {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🏠 Main Menu", callback_data: "main_menu" }]
                ]
            }
        }
    );
}

function requestPhoneNumber(chatId, userId) {
    userStates.set(userId, 'waiting_phone');
    
    bot.sendMessage(chatId, 
        "📱 *Enter WhatsApp number:*\nFormat: `254712345678`",
        { parse_mode: 'Markdown', reply_markup: { force_reply: true } }
    );
}

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = msg.text;

    if (!text || text.startsWith('/')) return;

    if (userStates.get(userId) === 'waiting_phone') {
        userStates.delete(userId);
        
        const cleanNumber = text.replace(/\D/g, '');
        if (cleanNumber.length < 10) {
            bot.sendMessage(chatId, "❌ Invalid number. Too short.");
            return;
        }

        bot.sendMessage(chatId, "⏳ Generating pairing code...");

        try {
            const code = await getPairCode(userId.toString(), cleanNumber);
            activeSessions.set(userId, { number: cleanNumber, time: new Date() });
            
            bot.sendMessage(chatId,
                "🔐 *YOUR PAIRING CODE*\n\n" +
                `\`${code}\`\n\n` +
                "⚡ *Enter immediately!* (30s)",
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "🔄 Try QR", callback_data: "qr_code" }],
                            [{ text: "🏠 Menu", callback_data: "main_menu" }]
                        ]
                    }
                }
            );
        } catch (err) {
            bot.sendMessage(chatId, `❌ Error: ${err.message}`);
        }
    }
});

async function generateQRCode(chatId, userId) {
    bot.sendMessage(chatId, "⏳ Generating QR code...");
    
    try {
        const { image } = await getQRCode(userId.toString());
        activeSessions.set(userId, { time: new Date() });
        
        await bot.sendPhoto(chatId, image, {
            caption: "📷 *SCAN THIS QR CODE*\n\n" +
                    "1. Open WhatsApp\n" +
                    "2. Settings → Linked Devices\n" +
                    "3. Tap 'Link a Device'\n" +
                    "4. Scan QR\n\n" +
                    "⏰ Expires in 60s",
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 Try Pairing Code", callback_data: "pairing_code" }],
                    [{ text: "🏠 Menu", callback_data: "main_menu" }]
                ]
            }
        });
    } catch (err) {
        bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
}

console.log('🤖 ACE BOT is running...');
console.log('⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】');
