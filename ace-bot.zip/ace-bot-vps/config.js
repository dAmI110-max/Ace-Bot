module.exports = {
  telegramToken: "8619246270:AAH6y8XIrgpAWGZxiOiv-aovMlQYb4jJFWw",
  botName: "ACE BOT",
}
