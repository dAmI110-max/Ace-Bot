require('dotenv').config();
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, DisconnectReason } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs-extra');
const path = require('path');
const EventEmitter = require('events');

class ACEBot extends EventEmitter {
    constructor() {
        super();
        this.sock = null;
        this.groupsData = new Map();
        this.usersData = new Map();
        this.sessionStartTime = Date.now();
        
        // Initialize modules
        this.TelegramBridge = require('./core/telegram-bridge');
        this.MessageHandler = require('./handlers/message-handler');
        this.GroupHandler = require('./handlers/group-handler');
        this.CommandHandler = require('./handlers/command-handler');
        this.AntiSpam = require('./features/anti-spam');
        this.AntiLink = require('./features/anti-link');
        this.AutoReply = require('./features/auto-reply');
        this.FunAnti = require('./features/fun-anti');
        
        this.telegram = new this.TelegramBridge(this);
        this.messageHandler = new this.MessageHandler(this);
        this.groupHandler = new this.GroupHandler(this);
        this.commandHandler = new this.CommandHandler(this);
        this.antiSpam = new this.AntiSpam(this);
        this.antiLink = new this.AntiLink(this);
        this.autoReply = new this.AutoReply(this);
        this.funAnti = new this.FunAnti(this);
        
        this.init();
    }

    async init() {
        console.log('⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】');
        console.log('🤖 Initializing ACE♡ Bot...');
        
        await this.connectWhatsApp();
        this.telegram.init();
        
        // Handle telegram pair requests
        this.on('telegram-pair-request', async ({ userId, number, resolve, reject }) => {
            try {
                const code = await this.telegramGetPairCode(userId, number);
                resolve(code);
            } catch (err) {
                reject(err);
            }
        });
    }

    async connectWhatsApp() {
        const { state, saveCreds } = await useMultiFileAuthState('./sessions/whatsapp');
        const { version } = await fetchLatestBaileysVersion();

        this.sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            logger: P({ level: 'silent' }),
            browser: Browsers.macOS('Safari'),
            markOnlineOnConnect: true,
            syncFullHistory: false,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000
        });

        this.sock.ev.on('creds.update', saveCreds);

        this.sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log('📱 QR Code received');
                this.telegram.sendQR(qr);
            }

            if (connection === 'open') {
                console.log('✅ WhatsApp Connected!');
                this.telegram.sendNotification('✅ *WhatsApp Connected!*\\n\\nACE♡ Bot is now online.');
                
                if (process.env.AUTO_JOIN_GROUP === 'true') {
                    await this.joinGroup();
                }
            }

            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                if (shouldReconnect) {
                    console.log('🔄 Reconnecting...');
                    setTimeout(() => this.connectWhatsApp(), 5000);
                }
            }
        });

        this.sock.ev.on('messages.upsert', async (m) => {
            await this.messageHandler.handle(m);
        });

        this.sock.ev.on('group-participants.update', async (update) => {
            await this.groupHandler.handleParticipants(update);
        });
    }

    async joinGroup() {
        try {
            const groupLink = process.env.WHATSAPP_GROUP_LINK;
            const code = groupLink.split('https://chat.whatsapp.com/')[1].split('?')[0];
            const response = await this.sock.groupAcceptInvite(code);
            console.log('✅ Auto-joined group:', response);
        } catch (err) {
            console.log('⚠️ Could not auto-join group:', err.message);
        }
    }

    async telegramGetPairCode(userId, number) {
        return new Promise(async (resolve, reject) => {
            try {
                // Create temporary socket for pairing
                const { state, saveCreds } = await useMultiFileAuthState(`./sessions/pair_${userId}`);
                const { version } = await fetchLatestBaileysVersion();
                
                const sock = makeWASocket({
                    version,
                    auth: state,
                    printQRInTerminal: false,
                    logger: P({ level: 'silent' }),
                    browser: Browsers.macOS('Safari')
                });
                
                sock.ev.on('creds.update', saveCreds);
                
                sock.ev.on('connection.update', async (update) => {
                    const { qr } = update;
                    
                    if (qr && !sock.authState.creds.registered) {
                        try {
                            await new Promise(r => setTimeout(r, 2000));
                            const cleanNumber = number.replace(/\D/g, '');
                            const code = await sock.requestPairingCode(cleanNumber);
                            resolve(code);
                        } catch (err) {
                            reject(err);
                        }
                    }
                });
                
                // Timeout
                setTimeout(() => {
                    reject(new Error('Pairing timeout'));
                }, 60000);
                
            } catch (err) {
                reject(err);
            }
        });
    }

    async sendACEMessage(jid, text, options = {}) {
        const brandedText = `${text}\n\n⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】`;
        return await this.sock.sendMessage(jid, { text: brandedText, ...options });
    }

    async sendChannelPromotion(jid) {
        const channelLink = process.env.WHATSAPP_CHANNEL_LINK;
        const text = `📢 *Join Our Official Channel!*\n\nStay updated:\n${channelLink}\n\n⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】`;
        return await this.sock.sendMessage(jid, { text });
    }
}

new ACEBot();
