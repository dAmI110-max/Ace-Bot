require('dotenv').config();
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, DisconnectReason } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs-extra');
const EventEmitter = require('events');

class ACEBot extends EventEmitter {
    constructor() {
        super();
        this.sock = null;
        this.groupsData = new Map();
        this.usersData = new Map();
        this.sessionStartTime = Date.now();
        this.connectionRetries = 0;
        this.maxRetries = 5;
        
        this.TelegramBridge = require('./core/telegram-bridge');
        this.MessageHandler = require('./handlers/message-handler');
        this.GroupHandler = require('./handlers/group-handler');
        this.CommandHandler = require('./handlers/command-handler');
        this.AntiSpam = require('./features/anti-spam');
        this.AntiLink = require('./features/anti-link');
        this.AutoReply = require('./features/auto-reply');
        this.FunAnti = require('./features/fun-anti');
        
        this.telegram = new this.TelegramBridge(this);
        this.messageHandler = new this.MessageHandler(this);
        this.groupHandler = new this.GroupHandler(this);
        this.commandHandler = new this.CommandHandler(this);
        this.antiSpam = new this.AntiSpam(this);
        this.antiLink = new this.AntiLink(this);
        this.autoReply = new this.AutoReply(this);
        this.funAnti = new this.FunAnti(this);
        
        this.init();
    }

    async init() {
        console.log('⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】');
        console.log('🤖 Initializing ACE♡ Bot...');
        
        await this.connectWhatsApp();
        this.telegram.init();
        
        this.on('telegram-pair-request', async ({ userId, number, resolve, reject }) => {
            try {
                const code = await this.telegramGetPairCode(userId, number);
                resolve(code);
            } catch (err) {
                reject(err);
            }
        });
    }

    async connectWhatsApp() {
        const { state, saveCreds } = await useMultiFileAuthState('./sessions/whatsapp');
        const { version } = await fetchLatestBaileysVersion();

        // Check if already authenticated
        if (state.creds.registered) {
            console.log('✅ Found existing session, connecting...');
        }

        this.sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: true, // Keep true for first setup
            logger: P({ level: 'silent' }),
            browser: Browsers.macOS('Safari'),
            markOnlineOnConnect: true,
            syncFullHistory: false,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000, // Keep connection alive
            emitOwnEvents: false,
            fireInitQueries: true
        });

        this.sock.ev.on('creds.update', saveCreds);

        this.sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr, receivedPendingNotifications } = update;

            // QR Code received - only show if not registered
            if (qr && !this.sock.authState.creds.registered) {
                console.log('📱 QR Code received - Scan now!');
                console.log('⏰ QR expires in 60 seconds');
                this.telegram.sendQR(qr);
                
                // Don't spam QR - wait for scan
                await new Promise(r => setTimeout(r, 60000));
            }

            // Connection open
            if (connection === 'open') {
                console.log('✅ WhatsApp Connected Successfully!');
                console.log('🎉 Bot is now active and ready!');
                this.connectionRetries = 0;
                
                this.telegram.sendNotification(
                    '✅ *WhatsApp Connected!*\\n\\n' +
                    '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】\\n' +
                    'ACE♡ Bot is now online and ready to use!\\n\\n' +
                    'Users can now pair via Telegram.'
                );
                
                // Auto-join group if configured
                if (process.env.AUTO_JOIN_GROUP === 'true') {
                    await this.joinGroup();
                }
            }

            // Connection close
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                console.log(`⚠️ Connection closed: ${statusCode}`);
                
                if (shouldReconnect && this.connectionRetries < this.maxRetries) {
                    this.connectionRetries++;
                    console.log(`🔄 Reconnecting... (Attempt ${this.connectionRetries}/${this.maxRetries})`);
                    
                    // Exponential backoff
                    const delay = Math.min(5000 * this.connectionRetries, 30000);
                    setTimeout(() => this.connectWhatsApp(), delay);
                } else if (this.connectionRetries >= this.maxRetries) {
                    console.log('❌ Max retries reached. Please restart manually.');
                    this.telegram.sendNotification('❌ Bot disconnected. Please restart Termux.');
                }
            }
        });

        // Messages handler
        this.sock.ev.on('messages.upsert', async (m) => {
            await this.messageHandler.handle(m);
        });

        // Group participants
        this.sock.ev.on('group-participants.update', async (update) => {
            await this.groupHandler.handleParticipants(update);
        });
    }

    async joinGroup() {
        try {
            const groupLink = process.env.WHATSAPP_GROUP_LINK;
            const code = groupLink.split('https://chat.whatsapp.com/')[1].split('?')[0];
            const response = await this.sock.groupAcceptInvite(code);
            console.log('✅ Auto-joined group:', response);
        } catch (err) {
            console.log('⚠️ Could not auto-join group:', err.message);
        }
    }

    async telegramGetPairCode(userId, number) {
        return new Promise(async (resolve, reject) => {
            try {
                const sessionPath = `./sessions/pair_${userId}`;
                const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
                const { version } = await fetchLatestBaileysVersion();
                
                const sock = makeWASocket({
                    version,
                    auth: state,
                    printQRInTerminal: false,
                    logger: P({ level: 'silent' }),
                    browser: Browsers.macOS('Safari'),
                    connectTimeoutMs: 120000, // 2 minutes
                    defaultQueryTimeoutMs: 120000
                });
                
                let resolved = false;
                
                sock.ev.on('creds.update', saveCreds);
                
                sock.ev.on('connection.update', async (update) => {
                    const { qr, connection } = update;
                    
                    if (qr && !resolved && !sock.authState.creds.registered) {
                        try {
                            // Wait for socket to stabilize
                            await new Promise(r => setTimeout(r, 3000));
                            
                            const cleanNumber = number.replace(/\D/g, '');
                            console.log(`Requesting pairing code for: ${cleanNumber}`);
                            
                            const code = await sock.requestPairingCode(cleanNumber);
                            console.log(`✅ Pairing code generated: ${code}`);
                            
                            resolved = true;
                            resolve(code);
                            
                            // Keep socket alive for 90 seconds to allow entry
                            setTimeout(() => {
                                console.log('Pairing session closed');
                            }, 90000);
                            
                        } catch (err) {
                            console.error('Pairing error:', err.message);
                            if (!resolved) {
                                resolved = true;
                                reject(new Error('Failed to generate pairing code. Try again.'));
                            }
                        }
                    }
                    
                    if (connection === 'open') {
                        console.log('Pairing session connected!');
                    }
                });
                
                // Timeout after 2 minutes
                setTimeout(() => {
                    if (!resolved) {
                        resolved = true;
                        reject(new Error('Pairing timeout - WhatsApp did not respond. Try again.'));
                    }
                }, 120000);
                
            } catch (err) {
                reject(new Error(`Pairing failed: ${err.message}`));
            }
        });
    }

    async sendACEMessage(jid, text, options = {}) {
        const brandedText = `${text}\n\n⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】`;
        return await this.sock.sendMessage(jid, { text: brandedText, ...options });
    }

    async sendChannelPromotion(jid) {
        const channelLink = process.env.WHATSAPP_CHANNEL_LINK;
        const text = `📢 *Join Our Official Channel!*\n\nStay updated:\n${channelLink}\n\n⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】`;
        return await this.sock.sendMessage(jid, { text });
    }
}

new ACEBot();

