cat > group-handler.js << 'EOF'
class GroupHandler {
    constructor(aceBot) {
        this.ace = aceBot;
    }

    async handleParticipants(update) {
        const { id, participants, action } = update;
        
        if (action === 'add') {
            for (const participant of participants) {
                await this.handleNewParticipant(id, participant);
            }
        }
    }

    async handleNewParticipant(groupJid, participantJid) {
        if (process.env.WELCOME_MESSAGE_ENABLED === 'true') {
            const welcomeText = `🎉 *Welcome to the Group!* 🎉\n\n👋 Hello @${participantJid.split('@')[0]}!\n\n⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 welcomes you!\n\n📢 *Join our official channel:*\n${process.env.WHATSAPP_CHANNEL_LINK}\n\n🤖 *Bot Commands:*\n• !menu - Show menu\n• !help - Get help\n• !rules - Group rules\n\nEnjoy your stay! ⛧`;
            
            await this.ace.sendACEMessage(groupJid, welcomeText);
            
            setTimeout(async () => {
                await this.ace.sendChannelPromotion(groupJid);
            }, 2000);
        }
    }
}

module.exports = GroupHandler;
EOF
