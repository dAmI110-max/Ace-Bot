class CommandHandler {
    constructor(aceBot) {
        this.ace = aceBot;
        this.prefix = process.env.PREFIX || '!';
    }

    async handle(message, userJid, groupJid, isAdmin) {
        const text = message.conversation || message.extendedTextMessage?.text || '';
        
        if (!text.startsWith(this.prefix)) return;
        
        const args = text.slice(this.prefix.length).trim().split(' ');
        const command = args.shift().toLowerCase();
        
        const isGroup = !!groupJid;

        switch(command) {
            case 'menu':
                await this.cmdMenu(userJid, groupJid);
                break;
            case 'help':
                await this.cmdHelp(userJid, groupJid);
                break;
            case 'antilink':
                if (isGroup && isAdmin) await this.cmdAntiLink(groupJid, args);
                break;
            case 'antispam':
                if (isGroup && isAdmin) await this.cmdAntiSpam(groupJid, args);
                break;
            case 'owner':
                await this.cmdOwner(userJid, groupJid);
                break;
            case 'channel':
                await this.cmdChannel(userJid, groupJid);
                break;
            default:
                // Unknown command
                break;
        }
    }

    async cmdMenu(jid, groupJid) {
        const target = groupJid || jid;
        const menu = `
╔════════════════════════════════════╗
║           🤖 ACE♡ BOT MENU         ║
╚════════════════════════════════════╝

*Group Commands:*
• !antilink on/off - Anti-link protection
• !antispam on - Anti-spam protection
• !antidry on - Anti-boring people
• !antighost on - Remove lurkers

*General Commands:*
• !menu - Show this menu
• !help - Get help
• !owner - Contact owner
• !channel - Join our channel

⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】
        `;
        await this.ace.sendACEMessage(target, menu);
    }

    async cmdHelp(jid, groupJid) {
        const target = groupJid || jid;
        const help = `
❓ *ACE♡ BOT HELP*

*How to use:*
1. Add me to your group
2. Give me admin rights
3. Use commands with ${this.prefix} prefix

*Support:* +2349040464374
*Channel:* ${process.env.WHATSAPP_CHANNEL_LINK}

⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】
        `;
        await this.ace.sendACEMessage(target, help);
    }

    async cmdAntiLink(groupJid, args) {
        const action = args[0];
        if (action === 'on') {
            this.ace.antiLink.setAntiLink(groupJid, true);
            await this.ace.sendACEMessage(groupJid, '✅ Anti-link enabled!');
        } else if (action === 'off') {
            this.ace.antiLink.setAntiLink(groupJid, false);
            await this.ace.sendACEMessage(groupJid, '❌ Anti-link disabled!');
        }
    }

    async cmdAntiSpam(groupJid, args) {
        this.ace.antiSpam.enableAntiSpam(groupJid);
        await this.ace.sendACEMessage(groupJid, '✅ Anti-spam enabled!');
    }

    async cmdOwner(jid, groupJid) {
        const target = groupJid || jid;
        await this.ace.sendACEMessage(target, 
            '👑 *Owner:* ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】\n📞 *Contact:* +2349040464374'
        );
    }

    async cmdChannel(jid, groupJid) {
        const target = groupJid || jid;
        await this.ace.sendACEMessage(target, 
            `📢 *Join our channel:*\n${process.env.WHATSAPP_CHANNEL_LINK}`
        );
    }
}

module.exports = CommandHandler;
