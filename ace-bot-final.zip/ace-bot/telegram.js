// In requestPhoneNumber function, replace the try-catch:

try {
    const code = await getPairCode(userId.toString(), cleanNumber);
    activeSessions.set(userId, { number: cleanNumber, time: new Date() });
    
    bot.sendMessage(chatId,
        "🔐 *YOUR PAIRING CODE*\n\n" +
        `\`${code}\`\n\n` +
        "⚡ *Enter this code IMMEDIATELY!*\n" +
        "⏰ Expires in 60 seconds\n\n" +
        "*How to enter:*\n" +
        "1. Open WhatsApp on your phone\n" +
        "2. Tap ⋮ (3 dots) → Settings\n" +
        "3. Tap 'Linked Devices'\n" +
        "4. Tap 'Link a Device'\n" +
        "5. Tap 'Link with phone number instead'\n" +
        "6. Enter the code above\n\n" +
        "⚠️ Type fast! Code expires quickly!",
        {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 Try Again", callback_data: "pairing_code" }],
                    [{ text: "🏠 Menu", callback_data: "main_menu" }]
                ]
            }
        }
    );
    
    // Auto-delete message after 2 minutes
    setTimeout(() => {
        bot.sendMessage(chatId, "⏰ Pairing code expired. Request new one if needed.");
    }, 120000);
    
} catch (err) {
    console.error('Pairing error:', err);
    bot.sendMessage(chatId,
        `❌ *Error:* ${err.message}\n\n` +
        `Common fixes:\n` +
        `• Make sure number has country code (e.g., 234...)\n` +
        `• Check your internet connection\n` +
        `• Try QR code instead`,
        {
            reply_markup: {
                inline_keyboard: [
                    [{ text: "📷 Try QR Code", callback_data: "qr_code" }],
                    [{ text: "🔄 Try Again", callback_data: "pairing_code" }]
                ]
            }
        }
    );
}

