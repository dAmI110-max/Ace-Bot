class AutoReply {
    constructor(aceBot) {
        this.ace = aceBot;
        this.responses = {
            greetings: [
                "Yo! What's up? 👋",
                "Hey there! How you doing? 😊",
                "Wassup! How can I help? ⛧",
                "Hello! Ready to vibe? 🎭"
            ],
            busy: [
                "Hold up, let me check... ⏳",
                "Give me a sec... 👀",
                "Processing that... 🔄",
                "One moment... 🧠"
            ],
            unknown: [
                "Hmm, I don't get that. Try !help 🤔",
                "Say what now? 😅 Use !help",
                "Not sure I understand. Check my commands! 📜",
                "Omo, I no understand o! Try !help 😂"
            ]
        };
    }

    async handle(message, userJid, groupJid) {
        if (!process.env.AUTO_REPLY_ENABLED === 'true') return;
        
        const text = message.conversation || message.extendedTextMessage?.text || '';
        const lowerText = text.toLowerCase();

        if (text.startsWith('!') || text.startsWith('/')) return;

        await this.simulateTyping(groupJid || userJid);

        if (this.isGreeting(lowerText)) {
            const reply = this.getRandomResponse('greetings');
            await this.ace.sendACEMessage(groupJid || userJid, reply);
            return;
        }

        if (text.includes('?')) {
            await this.handleQuestion(groupJid || userJid, text);
            return;
        }

        await this.ace.sendACEMessage(groupJid || userJid, this.getRandomResponse('unknown'));
    }

    isGreeting(text) {
        const greetings = ['hi', 'hello', 'hey', 'wassup', 'yo', 'good morning', 'good afternoon', 'good evening'];
        return greetings.some(g => text.includes(g));
    }

    async simulateTyping(jid) {
        await this.ace.sock.sendPresenceUpdate('composing', jid);
        const delay = Math.floor(Math.random() * 2000) + 1000;
        await new Promise(r => setTimeout(r, delay));
        await this.ace.sock.sendPresenceUpdate('paused', jid);
    }

    getRandomResponse(category) {
        const responses = this.responses[category];
        return responses[Math.floor(Math.random() * responses.length)];
    }

    async handleQuestion(jid, question) {
        const busy = this.getRandomResponse('busy');
        await this.ace.sendACEMessage(jid, busy);
        await new Promise(r => setTimeout(r, 1500));

        if (question.includes('help')) {
            await this.ace.sendACEMessage(jid, 
                "📜 *Commands:*\n!menu - Show menu\n!sticker - Make sticker\n!group - Group features\n!owner - Contact owner"
            );
        }
        else if (question.includes('owner') || question.includes('ace')) {
            await this.ace.sendACEMessage(jid, 
                "⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 is my creator!\nContact: +2349040464374"
            );
        }
        else {
            await this.ace.sendACEMessage(jid, 
                "I'm not sure, but my owner can help! Contact: +2349040464374 📞"
            );
        }
    }
}

module.exports = AutoReply;
