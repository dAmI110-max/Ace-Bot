class FunAnti {
    constructor(aceBot) {
        this.ace = aceBot;
        this.groupActivity = new Map();
        this.dryScore = new Map();
    }

    updateActivity(userJid, groupJid) {
        this.groupActivity.set(`${groupJid}:${userJid}`, Date.now());
        this.groupActivity.set(groupJid, Date.now());
    }

    async checkDry(userJid, groupJid, message) {
        const text = message.conversation || '';
        const words = text.split(' ').length;
        
        if (words < 3) {
            const key = `${groupJid}:${userJid}`;
            this.dryScore.set(key, (this.dryScore.get(key) || 0) + 1);
            
            if (this.dryScore.get(key) >= 5) {
                await this.ace.sendACEMessage(groupJid, 
                    `😭 @${userJid.split('@')[0]} Omo you dey dry chat! Contribute or bounce!`
                );
                this.dryScore.set(key, 0);
            }
        }
    }

    async checkFlex(userJid, groupJid, message) {
        const text = (message.conversation || '').toLowerCase();
        const flexWords = ['rich', 'money', 'dangote', 'billionaire', 'millionaire', 'wealthy', 'expensive', 'luxury'];
        
        const isFlexing = flexWords.some(word => text.includes(word));
        
        if (isFlexing) {
            await this.ace.sendACEMessage(groupJid,
                `😭 @${userJid.split('@')[0]} Calm down Dangote! We hear you!`
            );
        }
    }

    async checkRizz(userJid, groupJid, message) {
        const text = (message.conversation || '').toLowerCase();
        const rizzWords = ['baby', 'sweetheart', 'love', 'dear', 'beautiful', 'fine girl', 'handsome', 'crush'];
        
        const isRizzing = rizzWords.some(word => text.includes(word));
        
        if (isRizzing && Math.random() > 0.7) {
            await this.ace.sendACEMessage(groupJid,
                `😂 @${userJid.split('@')[0]} Anti-rizz activated! No flirting here!`
            );
        }
    }

    async antiSleep(groupJid) {
        const now = Date.now();
        const lastActivity = this.groupActivity.get(groupJid) || 0;
        
        if (now - lastActivity > 3600000) {
            await this.ace.sendACEMessage(groupJid,
                `😴 Everybody don kpai? Anti-sleep activated!\n\nWho's online? React with 👋`
            );
        }
        
        this.groupActivity.set(groupJid, now);
    }
}

module.exports = FunAnti;
