class AntiLink {
    constructor(aceBot) {
        this.ace = aceBot;
        this.groupSettings = new Map();
        
        this.linkPatterns = [
            /https?:\/\/[^\s]+/gi,
            /www\.[^\s]+/gi,
            /chat\.whatsapp\.com\/[^\s]+/gi,
            /t\.me\/[^\s]+/gi,
            /instagram\.com\/[^\s]+/gi,
            /youtube\.com\/[^\s]+/gi,
            /youtu\.be\/[^\s]+/gi,
            /facebook\.com\/[^\s]+/gi,
            /twitter\.com\/[^\s]+/gi,
            /x\.com\/[^\s]+/gi,
            /tiktok\.com\/[^\s]+/gi
        ];
    }

    async check(message, groupJid, senderJid, isAdmin) {
        if (isAdmin) return;
        
        const settings = this.groupSettings.get(groupJid) || {
            antiLink: false,
            antiLinkHard: false,
            whitelist: []
        };

        if (!settings.antiLink && !settings.antiLinkHard) return;

        const text = message.conversation || message.extendedTextMessage?.text || '';
        const hasLink = this.linkPatterns.some(pattern => pattern.test(text));
        
        if (hasLink) {
            const isWhitelisted = settings.whitelist.some(allowed => text.includes(allowed));
            if (isWhitelisted) return;

            if (settings.antiLinkHard) {
                await this.removeMessage(groupJid, message.key);
                await this.ace.sock.groupParticipantsUpdate(groupJid, [senderJid], 'remove');
                await this.ace.sendACEMessage(groupJid, `🚫 @${senderJid.split('@')[0]} removed for links!`);
            } else {
                await this.removeMessage(groupJid, message.key);
                await this.ace.sendACEMessage(groupJid, `⚠️ @${senderJid.split('@')[0]} Links not allowed!`);
            }
        }
    }

    async removeMessage(groupJid, messageKey) {
        try {
            await this.ace.sock.sendMessage(groupJid, { delete: messageKey });
        } catch (err) {
            console.log('Delete failed:', err.message);
        }
    }

    setAntiLink(groupJid, enabled, hard = false) {
        const settings = this.groupSettings.get(groupJid) || {};
        settings.antiLink = enabled;
        settings.antiLinkHard = hard;
        this.groupSettings.set(groupJid, settings);
    }

    addWhitelist(groupJid, url) {
        const settings = this.groupSettings.get(groupJid) || {};
        settings.whitelist = settings.whitelist || [];
        settings.whitelist.push(url);
        this.groupSettings.set(groupJid, settings);
    }
}

module.exports = AntiLink;
