class AntiSpam {
    constructor(aceBot) {
        this.ace = aceBot;
        this.userMessages = new Map();
        this.groupSettings = new Map();
        this.defaultLimit = 10;
        this.spamWindow = 60000;
    }

    async check(userJid, groupJid, isAdmin) {
        if (isAdmin) return false;
        
        const settings = this.groupSettings.get(groupJid) || { antiSpam: false, limit: this.defaultLimit };
        if (!settings.antiSpam) return false;

        const now = Date.now();
        const userKey = `${groupJid}:${userJid}`;
        
        if (!this.userMessages.has(userKey)) {
            this.userMessages.set(userKey, []);
        }
        
        const messages = this.userMessages.get(userKey);
        const validMessages = messages.filter(time => now - time < this.spamWindow);
        validMessages.push(now);
        this.userMessages.set(userKey, validMessages);
        
        if (validMessages.length > settings.limit) {
            await this.punish(userJid, groupJid);
            return true;
        }
        
        return false;
    }

    async punish(userJid, groupJid) {
        try {
            await this.ace.sock.groupParticipantsUpdate(groupJid, [userJid], 'demote');
            await this.ace.sendACEMessage(groupJid, `🚫 @${userJid.split('@')[0]} muted for spamming!`);
            
            setTimeout(async () => {
                await this.ace.sock.groupParticipantsUpdate(groupJid, [userJid], 'promote');
            }, 300000);
        } catch (err) {
            console.log('Punish failed:', err.message);
        }
    }

    enableAntiSpam(groupJid) {
        const settings = this.groupSettings.get(groupJid) || {};
        settings.antiSpam = true;
        this.groupSettings.set(groupJid, settings);
    }

    setSpamLimit(groupJid, limit) {
        const settings = this.groupSettings.get(groupJid) || {};
        settings.antiSpam = true;
        settings.limit = limit;
        this.groupSettings.set(groupJid, settings);
    }
}

module.exports = AntiSpam;
