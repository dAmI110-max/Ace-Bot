const fs = require('fs-extra');
const path = require('path');

class Database {
    constructor() {
        this.dataPath = './data';
        this.groupsFile = path.join(this.dataPath, 'groups.json');
        this.usersFile = path.join(this.dataPath, 'users.json');
        this.settingsFile = path.join(this.dataPath, 'settings.json');
        
        this.init();
    }

    async init() {
        await fs.ensureDir(this.dataPath);
        
        if (!await fs.pathExists(this.groupsFile)) {
            await fs.writeJson(this.groupsFile, {});
        }
        if (!await fs.pathExists(this.usersFile)) {
            await fs.writeJson(this.usersFile, {});
        }
        if (!await fs.pathExists(this.settingsFile)) {
            await fs.writeJson(this.settingsFile, {});
        }
    }

    async getGroup(groupId) {
        const data = await fs.readJson(this.groupsFile);
        return data[groupId] || {};
    }

    async setGroup(groupId, data) {
        const groups = await fs.readJson(this.groupsFile);
        groups[groupId] = { ...groups[groupId], ...data };
        await fs.writeJson(this.groupsFile, groups);
    }

    async getUser(userId) {
        const data = await fs.readJson(this.usersFile);
        return data[userId] || {};
    }

    async setUser(userId, data) {
        const users = await fs.readJson(this.usersFile);
        users[userId] = { ...users[userId], ...data };
        await fs.writeJson(this.usersFile, users);
    }

    async getSettings() {
        return await fs.readJson(this.settingsFile);
    }

    async setSettings(data) {
        const settings = await fs.readJson(this.settingsFile);
        await fs.writeJson(this.settingsFile, { ...settings, ...data });
    }
}

module.exports = new Database();
