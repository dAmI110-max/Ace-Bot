const moment = require('moment');

class Helper {
    static formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    static formatTime(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    static getGreeting() {
        const hour = moment().hour();
        if (hour < 12) return 'Good morning';
        if (hour < 18) return 'Good afternoon';
        return 'Good evening';
    }

    static randomChoice(arr) {
        return arr[Math.floor(Math.random() * arr.length)];
    }

    static sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    static isUrl(str) {
        try {
            new URL(str);
            return true;
        } catch {
            return false;
        }
    }

    static sanitizePhone(number) {
        return number.replace(/\D/g, '');
    }

    static generateId() {
        return Math.random().toString(36).substring(2, 15);
    }
}

module.exports = Helper;
