cat > telegram-bridge.js << 'EOF'
const TelegramBot = require('node-telegram-bot-api');
const QRCode = require('qrcode');

class TelegramBridge {
    constructor(aceBot) {
        this.ace = aceBot;
        this.token = process.env.TELEGRAM_TOKEN;
        this.adminId = process.env.ADMIN_ID;
        this.bot = new TelegramBot(this.token, { polling: true });
        this.verifiedUsers = new Set();
    }

    init() {
        this.setupCommands();
        console.log('📱 Telegram Bridge Active');
    }

    setupCommands() {
        this.bot.onText(/\/start/, async (msg) => {
            await this.handleStart(msg);
        });

        this.bot.on('callback_query', async (query) => {
            await this.handleCallback(query);
        });
    }

    async handleStart(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const name = msg.from.first_name;

        if (this.verifiedUsers.has(userId)) {
            this.showMainMenu(chatId, name);
            return;
        }

        const welcome = `╔════════════════════════════════════╗\n║     ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】      ║\n║         𝐀𝐂𝐄 𝐁𝐎𝐓 𝐒𝐘𝐒𝐓𝐄𝐌          ║\n╚════════════════════════════════════╝\n\n👋 Welcome, ${name}!\n\n🔐 WhatsApp Pairing Service\n   by ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】\n\n⚠️ Join @Cybervault012 to continue`;

        this.bot.sendMessage(chatId, welcome, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [[
                    { text: "📢 Join Group", url: "https://t.me/Cybervault012" },
                    { text: "✓ Verify", callback_data: "verify" }
                ]]
            }
        });
    }

    async handleCallback(query) {
        const chatId = query.message.chat.id;
        const userId = query.from.id;
        const data = query.data;

        this.bot.answerCallbackQuery(query.id);

        if (data === 'verify') {
            this.verifiedUsers.add(userId);
            this.bot.editMessageText('✅ Verified!', {
                chat_id: chatId,
                message_id: query.message.message_id
            });
            this.showMainMenu(chatId, query.from.first_name);
        }
    }

    showMainMenu(chatId, name) {
        const menu = `⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】 𝐌𝐄𝐍𝐔\n\nHello ${name}! 👋`;
        
        this.bot.sendMessage(chatId, menu, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔢 Pairing Code", callback_data: "pairing_code" },
                        { text: "📷 QR Code", callback_data: "qr_code" }
                    ]
                ]
            }
        });
    }

    async sendQR(qrString) {
        try {
            const buffer = await QRCode.toBuffer(qrString);
            this.bot.sendPhoto(this.adminId, buffer, {
                caption: '📷 *WhatsApp QR Code*',
                parse_mode: 'Markdown'
            });
        } catch (err) {
            console.error('QR send failed:', err);
        }
    }

    sendNotification(text) {
        this.bot.sendMessage(this.adminId, text, { parse_mode: 'Markdown' });
    }
}

module.exports = TelegramBridge;
EOF
