#!/usr/bin/env python3
"""
Setup Script for DeepSeek AI Ultimate
Developer: @LordAceTech | Telegram: @CyberVault01
"""

import subprocess
import sys
import os

def print_banner():
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║   🤖 DEEPSEEK AI ULTIMATE - SETUP SCRIPT 🤖                   ║
    ║                                                               ║
    ║   Developer: @LordAceTech                                     ║
    ║   Telegram: @CyberVault01                                     ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def install_packages():
    """Install required packages"""
    packages = [
        "requests>=2.28.0",
        "pycryptodome>=3.15.0",
        "rich>=13.0.0",
        "pywhatkit>=5.4",
        "qrcode[pil]>=7.4.2",
        "pillow>=9.0.0",
        "urllib3>=1.26.0"
    ]
    
    optional_packages = [
        "wikipedia>=1.4.0",
        "googlesearch-python>=1.2.3"
    ]
    
    print("\n📦 Installing required packages...\n")
    
    for package in packages:
        print(f"Installing {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", package])
            print(f"  ✅ {package.split('>=')[0]} installed")
        except:
            print(f"  ❌ Failed to install {package}")
    
    print("\n📦 Installing optional packages (for enhanced features)...\n")
    
    for package in optional_packages:
        print(f"Installing {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", package])
            print(f"  ✅ {package.split('>=')[0]} installed")
        except:
            print(f"  ⚠️ Optional package {package} failed (non-critical)")
    
    print("\n" + "="*60)
    print("✅ Setup completed!")
    print("="*60)

def create_shortcut():
    """Create desktop shortcut (Windows only)"""
    if sys.platform == "win32":
        try:
            import winshell
            from win32com.client import Dispatch
            
            desktop = winshell.desktop()
            path = os.path.join(desktop, "DeepSeek AI Ultimate.lnk")
            target = os.path.join(os.getcwd(), "enhanced_deepseek_bot.py")
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(path)
            shortcut.Targetpath = sys.executable
            shortcut.Arguments = f'"{target}"'
            shortcut.WorkingDirectory = os.getcwd()
            shortcut.IconLocation = sys.executable
            shortcut.save()
            
            print(f"✅ Desktop shortcut created: {path}")
        except:
            print("⚠️ Could not create desktop shortcut")

def main():
    print_banner()
    
    print("\nThis script will install all required dependencies for DeepSeek AI Ultimate.")
    print("Make sure you have an active internet connection.\n")
    
    response = input("Continue with installation? (y/n): ").lower()
    
    if response == 'y':
        install_packages()
        
        if sys.platform == "win32":
            create_shortcut()
        
        print("\n🎉 Installation complete!")
        print("\nTo start the bot, run:")
        print("  python enhanced_deepseek_bot.py")
        print("\n📖 For help and documentation, see README.md")
        print("📢 Join our Telegram: https://t.me/+hb6tjU3R98c0MGVk")
        print("💎 Upgrade to Premium for WhatsApp Bot features!")
    else:
        print("\n❌ Installation cancelled.")

if __name__ == "__main__":
    main()
