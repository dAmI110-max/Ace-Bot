/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║                                                                           ║
 * ║   🤖 ACE♡ - ULTIMATE WHATSAPP BOT v3.0 🤖                                 ║
 * ║                                                                           ║
 * ║   ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】                                                      ║
 * ║                                                                           ║
 * ║   Features: 200+ Menus | Pairing Code | Human-like Auto-Reply             ║
 * ║             Sticker Watermark | Anti-Features | AI-Powered                ║
 * ║                                                                           ║
 * ║   WhatsApp Channel: https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i ║
 * ║   Support Group: https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo         ║
 * ║                                                                           ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

const {
    default: makeWASocket,
    DisconnectReason,
    useMultiFileAuthState,
    delay,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
    getAggregateVotesInPollMessage,
    makeInMemoryStore,
    proto
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');
const readline = require('readline');
const moment = require('moment-timezone');
const NodeCache = require('node-cache');
const { Boom } = require('@hapi/boom');

// Import custom modules
const { menuList } = require('./lib/menu');
const { antiFeatures } = require('./lib/anti-features');
const { stickerMaker } = require('./lib/sticker');
const { humanReply } = require('./lib/human-reply');
const { database } = require('./lib/database');
const { downloader } = require('./lib/downloader');
const { aiFeatures } = require('./lib/ai-features');
const { funFeatures } = require('./lib/fun');
const { groupFeatures } = require('./lib/group');
const { tools } = require('./lib/tools');
const { games } = require('./lib/games');
const { ownerFeatures } = require('./lib/owner');
const { islamic } = require('./lib/islamic');
const { nsfw } = require('./lib/nsfw');
const { economy } = require('./lib/economy');
const { welcome } = require('./lib/welcome');

// Configuration
const config = {
    botName: 'ACE♡',
    ownerName: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
    ownerNumber: '234XXXXXXXXXX', // Replace with your number
    prefix: ['.', '!', '#', '/'],
    channelLink: 'https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i',
    groupLink: 'https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo',
    timezone: 'Africa/Lagos',
    sessionName: 'ACE-Session',
    autoRead: true,
    autoTyping: true,
    autoRecord: false,
    antiCall: true,
    antiSpam: true,
    antiLink: true,
    antiBadword: true,
    antiDelete: true,
    antiEdit: true,
    antiFake: true,
    antiForeign: false,
    antiflood: true,
    spamLimit: 10,
    floodInterval: 5000,
    stickerWatermark: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
    stickerPack: 'ACE♡ Stickers',
    stickerAuthor: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】'
};

// Global variables
let sock = null;
let store = null;
let msgRetryCounterCache = new NodeCache();
let rateLimiter = new NodeCache({ stdTTL: 60 });
let spamTracker = new Map();
let deletedMessages = new Map();
let editedMessages = new Map();
let userActivity = new Map();
let groupStats = new Map();

// Logger setup
const logger = pino({ level: 'silent' });

// Readline interface for pairing code
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Question prompt helper
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

/**
 * Start the bot connection
 */
async function startBot() {
    console.log(chalk.cyan(`
    ╔═══════════════════════════════════════════════════════════════════════════╗
    ║                                                                           ║
    ║   ${chalk.magenta('🤖 ACE♡ - ULTIMATE WHATSAPP BOT v3.0 🤖')}                              ║
    ║                                                                           ║
    ║   ${chalk.yellow('⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】')}                                                     ║
    ║                                                                           ║
    ╚═══════════════════════════════════════════════════════════════════════════╝
    `));

    const { state, saveCreds } = await useMultiFileAuthState(config.sessionName);
    const { version } = await fetchLatestBaileysVersion();

    store = makeInMemoryStore({ logger });
    store.readFromFile('./database/store.json');
    setInterval(() => {
        store.writeToFile('./database/store.json');
    }, 10000);

    sock = makeWASocket({
        version,
        logger,
        printQRInTerminal: false, // Disable QR, use pairing code
        browser: Browsers.macOS('Desktop'),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, logger),
        },
        msgRetryCounterCache,
        generateHighQualityLinkPreview: true,
        getMessage,
    });

    store.bind(sock.ev);

    // Pairing code connection
    if (!sock.authState.creds.registered) {
        console.log(chalk.yellow('\n📱 Pairing Code Connection\n'));
        console.log(chalk.cyan('Enter your WhatsApp number with country code (e.g., 2348012345678):\n'));
        
        const phoneNumber = await question(chalk.green('Your Number: '));
        
        if (!phoneNumber || phoneNumber.length < 10) {
            console.log(chalk.red('❌ Invalid phone number!'));
            process.exit(1);
        }

        console.log(chalk.yellow('\n⏳ Generating pairing code...\n'));
        
        try {
            const code = await sock.requestPairingCode(phoneNumber.trim());
            console.log(chalk.green(`\n✅ Your Pairing Code: ${chalk.bgWhite.black(code)}\n`));
            console.log(chalk.cyan('📲 Open WhatsApp on your phone > Settings > Linked Devices > Link with Phone Number\n'));
            console.log(chalk.yellow('⏳ Waiting for connection...\n'));
        } catch (err) {
            console.log(chalk.red(`❌ Error: ${err.message}`));
            process.exit(1);
        }
    }

    // Connection update handler
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom)? 
                lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut : true;
            
            console.log(chalk.red('❌ Connection closed due to:'), lastDisconnect?.error);
            
            if (shouldReconnect) {
                console.log(chalk.yellow('🔄 Reconnecting...'));
                await delay(3000);
                startBot();
            }
        } else if (connection === 'open') {
            console.log(chalk.green(`\n✅ Connected successfully!`));
            console.log(chalk.cyan(`🤖 Bot: ${config.botName}`));
            console.log(chalk.cyan(`👤 Owner: ${config.ownerName}\n`));
            
            // Send startup message to owner
            await sendStartupMessage();
        }
    });

    // Credentials update
    sock.ev.on('creds.update', saveCreds);

    // Message handler
    sock.ev.on('messages.upsert', async (m) => {
        if (m.type !== 'notify') return;
        
        for (const msg of m.messages) {
            if (!msg.message) continue;
            
            // Store message for anti-delete/anti-edit
            storeMessage(msg);
            
            // Process message
            await processMessage(msg);
        }
    });

    // Message delete handler
    sock.ev.on('messages.update', async (updates) => {
        for (const update of updates) {
            if (update.update?.messageStubType === proto.WebMessageInfo.StubType.REVOKE) {
                await handleDeletedMessage(update);
            }
        }
    });

    // Group participants update
    sock.ev.on('group-participants.update', async (update) => {
        await handleGroupUpdate(update);
    });
}

/**
 * Get message from store
 */
async function getMessage(key) {
    if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg?.message || undefined;
    }
    return proto.Message.fromObject({});
}

/**
 * Store message for anti-delete/anti-edit
 */
function storeMessage(msg) {
    const key = `${msg.key.remoteJid}_${msg.key.id}`;
    deletedMessages.set(key, msg);
    
    // Clean old messages (keep last 1000)
    if (deletedMessages.size > 1000) {
        const firstKey = deletedMessages.keys().next().value;
        deletedMessages.delete(firstKey);
    }
}

/**
 * Process incoming message
 */
async function processMessage(msg) {
    try {
        const chatId = msg.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        const sender = msg.key.participant || chatId;
        const pushName = msg.pushName || 'Unknown';
        const isOwner = sender === config.ownerNumber + '@s.whatsapp.net';
        
        // Extract message content
        const messageType = Object.keys(msg.message)[0];
        const messageContent = msg.message[messageType];
        
        // Get text content
        let text = '';
        if (messageType === 'conversation') {
            text = messageContent;
        } else if (messageType === 'extendedTextMessage') {
            text = messageContent.text;
        } else if (messageType === 'imageMessage' || messageType === 'videoMessage') {
            text = messageContent.caption || '';
        }

        // Check if message starts with prefix
        const usedPrefix = config.prefix.find(p => text.startsWith(p));
        const command = usedPrefix ? text.slice(usedPrefix.length).trim().split(' ')[0].toLowerCase() : '';
        const args = usedPrefix ? text.slice(usedPrefix.length).trim().split(' ').slice(1) : [];
        const fullArgs = usedPrefix ? text.slice(usedPrefix.length).trim().slice(command.length).trim() : text;

        // Anti-features check
        if (isGroup && !isOwner) {
            const shouldBlock = await checkAntiFeatures(msg, chatId, sender, text, messageType);
            if (shouldBlock) return;
        }

        // Spam check
        if (config.antiSpam && !isOwner) {
            const isSpam = checkSpam(sender);
            if (isSpam) {
                await sock.sendMessage(chatId, {
                    text: '⏳ Please slow down! You\'re sending messages too fast.',
                    mentions: [sender]
                });
                return;
            }
        }

        // Human-like auto-reply for non-commands
        if (!usedPrefix && !isGroup) {
            await humanReply(sock, chatId, text, sender, pushName, config);
            return;
        }

        // Process commands
        if (usedPrefix) {
            console.log(chalk.cyan(`[${moment().format('HH:mm:ss')}]`), chalk.yellow(`${command}`), chalk.green(`from ${pushName}`));
            await processCommand(command, args, fullArgs, msg, chatId, sender, isGroup, isOwner, pushName);
        }

    } catch (err) {
        console.error(chalk.red('Error processing message:'), err);
    }
}

/**
 * Check anti-features
 */
async function checkAntiFeatures(msg, chatId, sender, text, messageType) {
    const groupMetadata = await sock.groupMetadata(chatId);
    const isAdmin = groupMetadata.participants.find(p => p.id === sender)?.admin;
    
    if (isAdmin) return false; // Don't apply to admins

    // Anti-link
    if (config.antiLink && /(https?:\/\/|www\.)[^\s]+/i.test(text)) {
        await sock.sendMessage(chatId, {
            text: `🚫 @${sender.split('@')[0]}, links are not allowed here!`,
            mentions: [sender]
        });
        await sock.groupParticipantsUpdate(chatId, [sender], 'remove');
        return true;
    }

    // Anti-badword
    if (config.antiBadword) {
        const badwords = ['fuck', 'shit', 'bitch', 'asshole', 'bastard', 'idiot', 'stupid'];
        const hasBadword = badwords.some(word => text.toLowerCase().includes(word));
        if (hasBadword) {
            await sock.sendMessage(chatId, {
                text: `⚠️ @${sender.split('@')[0]}, watch your language!`,
                mentions: [sender]
            });
            return true;
        }
    }

    // Anti-fake (non-Nigerian numbers)
    if (config.antiFake && !sender.startsWith('234')) {
        await sock.sendMessage(chatId, {
            text: `🚫 @${sender.split('@')[0]}, only Nigerian numbers allowed!`,
            mentions: [sender]
        });
        await sock.groupParticipantsUpdate(chatId, [sender], 'remove');
        return true;
    }

    // Anti-flood
    if (config.antiflood) {
        const now = Date.now();
        const userActivity = userActivity.get(sender) || { count: 0, lastMessage: now };
        
        if (now - userActivity.lastMessage < config.floodInterval) {
            userActivity.count++;
            if (userActivity.count > config.spamLimit) {
                await sock.sendMessage(chatId, {
                    text: `⏸️ @${sender.split('@')[0]} has been muted for flooding!`,
                    mentions: [sender]
                });
                // Mute user (implementation depends on group settings)
                return true;
            }
        } else {
            userActivity.count = 1;
        }
        userActivity.lastMessage = now;
        userActivity.set(sender, userActivity);
    }

    return false;
}

/**
 * Check spam
 */
function checkSpam(sender) {
    const now = Date.now();
    const userSpam = spamTracker.get(sender) || { count: 0, firstMessage: now };
    
    if (now - userSpam.firstMessage > 60000) {
        userSpam.count = 1;
        userSpam.firstMessage = now;
    } else {
        userSpam.count++;
    }
    
    spamTracker.set(sender, userSpam);
    return userSpam.count > config.spamLimit;
}

/**
 * Handle deleted message (Anti-delete)
 */
async function handleDeletedMessage(update) {
    if (!config.antiDelete) return;
    
    const key = `${update.key.remoteJid}_${update.key.id}`;
    const deletedMsg = deletedMessages.get(key);
    
    if (deletedMsg) {
        const sender = deletedMsg.key.participant || deletedMsg.key.remoteJid;
        const chatId = update.key.remoteJid;
        
        // Forward the deleted message
        await sock.sendMessage(chatId, {
            forward: deletedMsg,
            contextInfo: {
                externalAdReply: {
                    title: '🚨 Deleted Message Recovered',
                    body: `Deleted by @${sender.split('@')[0]}`,
                    showAdAttribution: true
                }
            }
        });
        
        // Send notification
        await sock.sendMessage(chatId, {
            text: `👀 @${sender.split('@')[0]} tried to delete a message!`,
            mentions: [sender]
        });
    }
}

/**
 * Handle group updates (welcome, goodbye, etc.)
 */
async function handleGroupUpdate(update) {
    const { id, participants, action } = update;
    
    if (action === 'add') {
        // Auto-add to group if bot is added
        for (const participant of participants) {
            if (participant === sock.user.id) {
                // Bot was added to group
                await sock.sendMessage(id, {
                    text: `🤖 *${config.botName}* has joined the group!\n\n` +
                          `Type *.menu* to see all commands.\n\n` +
                          `📢 Join our channel: ${config.channelLink}`
                });
                
                // Add bot to the support group
                try {
                    await sock.groupAcceptInvite(config.groupLink.split('/').pop());
                } catch (e) {}
            } else {
                // New member joined
                await welcome.handleJoin(sock, id, participant, config);
            }
        }
    } else if (action === 'remove') {
        for (const participant of participants) {
            await welcome.handleLeave(sock, id, participant, config);
        }
    }
}

/**
 * Process commands
 */
async function processCommand(command, args, fullArgs, msg, chatId, sender, isGroup, isOwner, pushName) {
    const quotedMsg = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedSender = msg.message.extendedTextMessage?.contextInfo?.participant;
    
    // Command context object
    const ctx = {
        sock,
        msg,
        chatId,
        sender,
        isGroup,
        isOwner,
        pushName,
        args,
        fullArgs,
        quotedMsg,
        quotedSender,
        config,
        store
    };

    // Execute command
    switch (command) {
        // ═══════════════════════════════════════════════════════════
        // MAIN MENU COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'menu':
        case 'help':
        case 'start':
            await menuList.allmenu(ctx);
            break;
            
        case 'allmenu':
            await menuList.allmenu(ctx);
            break;
            
        case 'ownermenu':
            await menuList.ownermenu(ctx);
            break;
            
        case 'groupmenu':
            await menuList.groupmenu(ctx);
            break;
            
        case 'antimenu':
            await menuList.antimenu(ctx);
            break;
            
        case 'downloadmenu':
            await menuList.downloadmenu(ctx);
            break;
            
        case 'stickermenu':
            await menuList.stickermenu(ctx);
            break;
            
        case 'aimenu':
            await menuList.aimenu(ctx);
            break;
            
        case 'funmenu':
            await menuList.funmenu(ctx);
            break;
            
        case 'gamemenu':
            await menuList.gamemenu(ctx);
            break;
            
        case 'toolsmenu':
            await menuList.toolsmenu(ctx);
            break;
            
        case 'islamicmenu':
            await menuList.islamicmenu(ctx);
            break;
            
        case 'nsfwmenu':
            await menuList.nsfwmenu(ctx);
            break;
            
        case 'economymenu':
            await menuList.economymenu(ctx);
            break;
            
        case 'infomenu':
            await menuList.infomenu(ctx);
            break;
            
        case 'convertmenu':
            await menuList.convertmenu(ctx);
            break;
            
        case 'searchmenu':
            await menuList.searchmenu(ctx);
            break;
            
        case 'animemenu':
            await menuList.animemenu(ctx);
            break;
            
        case 'photomenu':
            await menuList.photomenu(ctx);
            break;
            
        case 'videomenu':
            await menuList.videomenu(ctx);
            break;
            
        case 'voicemenu':
            await menuList.voicemenu(ctx);
            break;
            
        case 'textmenu':
            await menuList.textmenu(ctx);
            break;
            
        case 'logomenu':
            await menuList.logomenu(ctx);
            break;
            
        case 'maker menu':
            await menuList.makermenu(ctx);
            break;
            
        case 'randommenu':
            await menuList.randommenu(ctx);
            break;
            
        case 'othermenu':
            await menuList.othermenu(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // STICKER COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'sticker':
        case 's':
        case 'stiker':
            await stickerMaker.createSticker(ctx);
            break;
            
        case 'stickerwm':
        case 'swm':
            await stickerMaker.createStickerWithWM(ctx);
            break;
            
        case 'take':
        case 'steal':
            await stickerMaker.stealSticker(ctx);
            break;
            
        case 'toimg':
        case 'stickertoimage':
            await stickerMaker.stickerToImage(ctx);
            break;
            
        case 'tovideo':
        case 'stickertovideo':
            await stickerMaker.stickerToVideo(ctx);
            break;
            
        case 'togif':
            await stickerMaker.stickerToGif(ctx);
            break;
            
        case 'attp':
            await stickerMaker.attp(ctx);
            break;
            
        case 'ttp':
            await stickerMaker.ttp(ctx);
            break;
            
        case 'emojimix':
            await stickerMaker.emojiMix(ctx);
            break;
            
        case 'qc':
            await stickerMaker.quoteSticker(ctx);
            break;
            
        case 'smeme':
            await stickerMaker.stickerMeme(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // ANTI-FEATURE COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'antilink':
            await antiFeatures.toggleAntiLink(ctx);
            break;
            
        case 'antilinkhard':
            await antiFeatures.toggleAntiLinkHard(ctx);
            break;
            
        case 'antispam':
            await antiFeatures.toggleAntiSpam(ctx);
            break;
            
        case 'spamlimit':
            await antiFeatures.setSpamLimit(ctx);
            break;
            
        case 'antiflood':
            await antiFeatures.toggleAntiFlood(ctx);
            break;
            
        case 'antibot':
            await antiFeatures.toggleAntiBot(ctx);
            break;
            
        case 'antiforward':
            await antiFeatures.toggleAntiForward(ctx);
            break;
            
        case 'antilinkwhitelist':
            await antiFeatures.setLinkWhitelist(ctx);
            break;
            
        case 'antilinkwarn':
            await antiFeatures.toggleLinkWarn(ctx);
            break;
            
        case 'antilinkkick':
            await antiFeatures.toggleLinkKick(ctx);
            break;
            
        case 'antibadword':
            await antiFeatures.toggleAntiBadword(ctx);
            break;
            
        case 'badword':
            await antiFeatures.manageBadwords(ctx);
            break;
            
        case 'badwordlist':
            await antiFeatures.listBadwords(ctx);
            break;
            
        case 'antitoxic':
            await antiFeatures.toggleAntiToxic(ctx);
            break;
            
        case 'antinsfw':
            await antiFeatures.toggleAntiNSFW(ctx);
            break;
            
        case 'antiswear':
            await antiFeatures.toggleAntiSwear(ctx);
            break;
            
        case 'antibully':
            await antiFeatures.toggleAntiBully(ctx);
            break;
            
        case 'antirude':
            await antiFeatures.toggleAntiRude(ctx);
            break;
            
        case 'antihate':
            await antiFeatures.toggleAntiHate(ctx);
            break;
            
        case 'antifake':
            await antiFeatures.toggleAntiFake(ctx);
            break;
            
        case 'antiforeign':
            await antiFeatures.toggleAntiForeign(ctx);
            break;
            
        case 'antiprivate':
            await antiFeatures.toggleAntiPrivate(ctx);
            break;
            
        case 'antitagall':
            await antiFeatures.toggleAntiTagall(ctx);
            break;
            
        case 'antimention':
            await antiFeatures.toggleAntiMention(ctx);
            break;
            
        case 'antilurker':
            await antiFeatures.toggleAntiLurker(ctx);
            break;
            
        case 'antijoin':
            await antiFeatures.toggleAntiJoin(ctx);
            break;
            
        case 'antileave':
            await antiFeatures.toggleAntiLeave(ctx);
            break;
            
        case 'antiraid':
            await antiFeatures.toggleAntiRaid(ctx);
            break;
            
        case 'antifakeadmin':
            await antiFeatures.toggleAntiFakeAdmin(ctx);
            break;
            
        case 'antiimage':
            await antiFeatures.toggleAntiImage(ctx);
            break;
            
        case 'antivideo':
            await antiFeatures.toggleAntiVideo(ctx);
            break;
            
        case 'antiaudio':
            await antiFeatures.toggleAntiAudio(ctx);
            break;
            
        case 'antigif':
            await antiFeatures.toggleAntiGif(ctx);
            break;
            
        case 'antisticker':
            await antiFeatures.toggleAntiSticker(ctx);
            break;
            
        case 'antidocument':
            await antiFeatures.toggleAntiDocument(ctx);
            break;
            
        case 'antilinkpreview':
            await antiFeatures.toggleAntiLinkPreview(ctx);
            break;
            
        case 'antimediaall':
            await antiFeatures.toggleAntiMediaAll(ctx);
            break;
            
        case 'antiviewonce':
            await antiFeatures.toggleAntiViewOnce(ctx);
            break;
            
        case 'antiscreenshot':
            await antiFeatures.toggleAntiScreenshot(ctx);
            break;
            
        case 'antidelete':
            await antiFeatures.toggleAntiDelete(ctx);
            break;
            
        case 'antiedit':
            await antiFeatures.toggleAntiEdit(ctx);
            break;
            
        case 'antihack':
            await antiFeatures.toggleAntiHack(ctx);
            break;
            
        case 'antilogout':
            await antiFeatures.toggleAntiLogout(ctx);
            break;
            
        case 'antifakeprofile':
            await antiFeatures.toggleAntiFakeProfile(ctx);
            break;
            
        case 'antitracking':
            await antiFeatures.toggleAntiTracking(ctx);
            break;
            
        case 'antidox':
            await antiFeatures.toggleAntiDox(ctx);
            break;
            
        case 'antiphishing':
            await antiFeatures.toggleAntiPhishing(ctx);
            break;
            
        case 'antiscam':
            await antiFeatures.toggleAntiScam(ctx);
            break;
            
        case 'antifraud':
            await antiFeatures.toggleAntiFraud(ctx);
            break;
            
        case 'antiraidai':
            await antiFeatures.toggleAntiRaidAI(ctx);
            break;
            
        case 'antispamai':
            await antiFeatures.toggleAntiSpamAI(ctx);
            break;
            
        case 'toxicityfilter':
            await antiFeatures.toggleToxicityFilter(ctx);
            break;
            
        case 'smartwarn':
            await antiFeatures.toggleSmartWarn(ctx);
            break;
            
        case 'autosilence':
            await antiFeatures.toggleAutoSilence(ctx);
            break;
            
        case 'autokick':
            await antiFeatures.toggleAutoKick(ctx);
            break;
            
        case 'autoban':
            await antiFeatures.toggleAutoBan(ctx);
            break;
            
        case 'autoshadowban':
            await antiFeatures.toggleAutoShadowBan(ctx);
            break;
            
        case 'behaviortrack':
            await antiFeatures.toggleBehaviorTrack(ctx);
            break;
            
        case 'suspicionlevel':
            await antiFeatures.checkSuspicionLevel(ctx);
            break;
            
        // FUN ANTI COMMANDS
        case 'antidry':
            await antiFeatures.toggleAntiDry(ctx);
            break;
            
        case 'antighost':
            await antiFeatures.toggleAntiGhost(ctx);
            break;
            
        case 'antiflex':
            await antiFeatures.toggleAntiFlex(ctx);
            break;
            
        case 'antirizz':
            await antiFeatures.toggleAntiRizz(ctx);
            break;
            
        case 'antinoise':
            await antiFeatures.toggleAntiNoise(ctx);
            break;
            
        case 'antiview':
            await antiFeatures.toggleAntiView(ctx);
            break;
            
        case 'antiboring':
            await antiFeatures.toggleAntiBoring(ctx);
            break;
            
        case 'antidrama':
            await antiFeatures.toggleAntiDrama(ctx);
            break;
            
        case 'antisleep':
            await antiFeatures.toggleAntiSleep(ctx);
            break;
            
        case 'antistatusviewer':
            await antiFeatures.toggleAntiStatusViewer(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // GROUP COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'group':
        case 'grup':
            await groupFeatures.toggleGroup(ctx);
            break;
            
        case 'open':
            await groupFeatures.openGroup(ctx);
            break;
            
        case 'close':
            await groupFeatures.closeGroup(ctx);
            break;
            
        case 'setname':
        case 'setsubject':
            await groupFeatures.setName(ctx);
            break;
            
        case 'setdesc':
        case 'setdescription':
            await groupFeatures.setDesc(ctx);
            break;
            
        case 'promote':
            await groupFeatures.promote(ctx);
            break;
            
        case 'demote':
            await groupFeatures.demote(ctx);
            break;
            
        case 'kick':
            await groupFeatures.kick(ctx);
            break;
            
        case 'add':
            await groupFeatures.add(ctx);
            break;
            
        case 'invite':
            await groupFeatures.invite(ctx);
            break;
            
        case 'revoke':
            await groupFeatures.revoke(ctx);
            break;
            
        case 'tagall':
        case 'tag':
            await groupFeatures.tagAll(ctx);
            break;
            
        case 'hidetag':
        case 'ht':
            await groupFeatures.hideTag(ctx);
            break;
            
        case 'tagadmin':
            await groupFeatures.tagAdmin(ctx);
            break;
            
        case 'listonline':
            await groupFeatures.listOnline(ctx);
            break;
            
        case 'grouplink':
        case 'gclink':
            await groupFeatures.groupLink(ctx);
            break;
            
        case 'setppgroup':
            await groupFeatures.setPPGroup(ctx);
            break;
            
        case 'getbio':
            await groupFeatures.getBio(ctx);
            break;
            
        case 'vote':
            await groupFeatures.vote(ctx);
            break;
            
        case 'upvote':
            await groupFeatures.upvote(ctx);
            break;
            
        case 'downvote':
            await groupFeatures.downvote(ctx);
            break;
            
        case 'cekvote':
            await groupFeatures.checkVote(ctx);
            break;
            
        case 'hapusvote':
            await groupFeatures.deleteVote(ctx);
            break;
            
        case 'mute':
            await groupFeatures.mute(ctx);
            break;
            
        case 'unmute':
            await groupFeatures.unmute(ctx);
            break;
            
        case 'warn':
            await groupFeatures.warn(ctx);
            break;
            
        case 'unwarn':
            await groupFeatures.unwarn(ctx);
            break;
            
        case 'listwarn':
            await groupFeatures.listWarn(ctx);
            break;
            
        case 'resetwarn':
            await groupFeatures.resetWarn(ctx);
            break;
            
        case 'afk':
            await groupFeatures.setAFK(ctx);
            break;
            
        case 'delete':
        case 'del':
            await groupFeatures.deleteMessage(ctx);
            break;
            
        case 'pin':
            await groupFeatures.pinMessage(ctx);
            break;
            
        case 'unpin':
            await groupFeatures.unpinMessage(ctx);
            break;
            
        case 'ephemeral':
            await groupFeatures.setEphemeral(ctx);
            break;
            
        case 'disappearing':
            await groupFeatures.setDisappearing(ctx);
            break;
            
        case 'announce':
            await groupFeatures.setAnnounce(ctx);
            break;
            
        case 'restrict':
            await groupFeatures.setRestrict(ctx);
            break;
            
        case 'memberaddmode':
            await groupFeatures.setMemberAddMode(ctx);
            break;
            
        case 'approval':
            await groupFeatures.toggleApproval(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // DOWNLOADER COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'ytmp3':
        case 'ytaudio':
            await downloader.ytmp3(ctx);
            break;
            
        case 'ytmp4':
        case 'ytvideo':
            await downloader.ytmp4(ctx);
            break;
            
        case 'yts':
        case 'ytsearch':
            await downloader.ytSearch(ctx);
            break;
            
        case 'play':
            await downloader.play(ctx);
            break;
            
        case 'playdoc':
            await downloader.playDoc(ctx);
            break;
            
        case 'tiktok':
        case 'tt':
            await downloader.tiktok(ctx);
            break;
            
        case 'tiktokmp3':
            await downloader.tiktokMp3(ctx);
            break;
            
        case 'instagram':
        case 'ig':
            await downloader.instagram(ctx);
            break;
            
        case 'facebook':
        case 'fb':
            await downloader.facebook(ctx);
            break;
            
        case 'twitter':
        case 'x':
            await downloader.twitter(ctx);
            break;
            
        case 'spotify':
            await downloader.spotify(ctx);
            break;
            
        case 'soundcloud':
            await downloader.soundcloud(ctx);
            break;
            
        case 'mediafire':
            await downloader.mediafire(ctx);
            break;
            
        case 'gdrive':
            await downloader.gdrive(ctx);
            break;
            
        case 'pinterest':
            await downloader.pinterest(ctx);
            break;
            
        case 'threads':
            await downloader.threads(ctx);
            break;
            
        case 'snackvideo':
            await downloader.snackVideo(ctx);
            break;
            
        case 'likee':
            await downloader.likee(ctx);
            break;
            
        case 'capcut':
            await downloader.capcut(ctx);
            break;
            
        case 'storywa':
            await downloader.storyWa(ctx);
            break;
            
        case 'gitclone':
            await downloader.gitClone(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // AI COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'ai':
        case 'gpt':
        case 'openai':
            await aiFeatures.chatGPT(ctx);
            break;
            
        case 'bard':
            await aiFeatures.bard(ctx);
            break;
            
        case 'bing':
            await aiFeatures.bing(ctx);
            break;
            
        case 'claude':
            await aiFeatures.claude(ctx);
            break;
            
        case 'llama':
            await aiFeatures.llama(ctx);
            break;
            
        case 'blackbox':
            await aiFeatures.blackbox(ctx);
            break;
            
        case 'youai':
            await aiFeatures.youAI(ctx);
            break;
            
        case 'chatbot':
            await aiFeatures.toggleChatbot(ctx);
            break;
            
        case 'resetai':
            await aiFeatures.resetAI(ctx);
            break;
            
        case 'aiimage':
        case 'dalle':
        case 'diffusion':
            await aiFeatures.generateImage(ctx);
            break;
            
        case 'upscale':
        case 'enhance':
            await aiFeatures.upscaleImage(ctx);
            break;
            
        case 'removebg':
            await aiFeatures.removeBg(ctx);
            break;
            
        case 'toanime':
            await aiFeatures.toAnime(ctx);
            break;
            
        case 'tocartoon':
            await aiFeatures.toCartoon(ctx);
            break;
            
        case 'tovideo':
            await aiFeatures.imageToVideo(ctx);
            break;
            
        case 'voiceai':
            await aiFeatures.voiceAI(ctx);
            break;
            
        case 'texttoimage':
            await aiFeatures.textToImage(ctx);
            break;
            
        case 'imgtoimg':
            await aiFeatures.imgToImg(ctx);
            break;
            
        case 'face_swap':
            await aiFeatures.faceSwap(ctx);
            break;
            
        case 'colorize':
            await aiFeatures.colorize(ctx);
            break;
            
        case 'restorephoto':
            await aiFeatures.restorePhoto(ctx);
            break;
            
        case 'uncrop':
            await aiFeatures.uncrop(ctx);
            break;
            
        case 'relight':
            await aiFeatures.relight(ctx);
            break;
            
        case 'sketch':
            await aiFeatures.sketch(ctx);
            break;
            
        case 'codeai':
            await aiFeatures.codeAI(ctx);
            break;
            
        case 'explaincode':
            await aiFeatures.explainCode(ctx);
            break;
            
        case 'debugcode':
            await aiFeatures.debugCode(ctx);
            break;
            
        case 'translateai':
            await aiFeatures.translateAI(ctx);
            break;
            
        case 'summarize':
            await aiFeatures.summarize(ctx);
            break;
            
        case 'grammar':
            await aiFeatures.grammarCheck(ctx);
            break;
            
        case 'rewrite':
            await aiFeatures.rewrite(ctx);
            break;
            
        case 'essay':
            await aiFeatures.essayWriter(ctx);
            break;
            
        case 'storyai':
            await aiFeatures.storyAI(ctx);
            break;
            
        case 'poemai':
            await aiFeatures.poemAI(ctx);
            break;
            
        case 'lyricsai':
            await aiFeatures.lyricsAI(ctx);
            break;
            
        case 'rapai':
            await aiFeatures.rapAI(ctx);
            break;
            
        case 'roastai':
            await aiFeatures.roastAI(ctx);
            break;
            
        case 'complimentai':
            await aiFeatures.complimentAI(ctx);
            break;
            
        case 'pickupai':
            await aiFeatures.pickupAI(ctx);
            break;
            
        case 'jokeai':
            await aiFeatures.jokeAI(ctx);
            break;
            
        case 'factai':
            await aiFeatures.factAI(ctx);
            break;
            
        case 'horoscopeai':
            await aiFeatures.horoscopeAI(ctx);
            break;
            
        case 'dreamai':
            await aiFeatures.dreamAI(ctx);
            break;
            
        case 'tarotai':
            await aiFeatures.tarotAI(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // FUN COMMANDS
        // ═══════════════════════════════════════════════════════════
        case 'joke':
            await funFeatures.joke(ctx);
            break;
            
        case 'meme':
            await funFeatures.meme(ctx);
            break;
            
        case 'quote':
            await funFeatures.quote(ctx);
            break;
            
        case 'fact':
            await funFeatures.fact(ctx);
            break;
            
        case 'trivia':
            await funFeatures.trivia(ctx);
            break;
            
        case 'wouldyourather':
        case 'wyr':
            await funFeatures.wouldYouRather(ctx);
            break;
            
        case 'truth':
            await funFeatures.truth(ctx);
            break;
            
        case 'dare':
            await funFeatures.dare(ctx);
            break;
            
        case 'ship':
            await funFeatures.ship(ctx);
            break;
            
        case 'kiss':
            await funFeatures.kiss(ctx);
            break;
            
        case 'hug':
            await funFeatures.hug(ctx);
            break;
            
        case 'slap':
            await funFeatures.slap(ctx);
            break;
            
        case 'punch':
            await funFeatures.punch(ctx);
            break;
            
        case 'kill':
            await funFeatures.kill(ctx);
            break;
            
        case 'pat':
            await funFeatures.pat(ctx);
            break;
            
        case 'cuddle':
            await funFeatures.cuddle(ctx);
            break;
            
        case 'bonk':
            await funFeatures.bonk(ctx);
            break;
            
        case 'poke':
            await funFeatures.poke(ctx);
            break;
            
        case 'tickle':
            await funFeatures.tickle(ctx);
            break;
            
        case 'wave':
            await funFeatures.wave(ctx);
            break;
            
        case 'wink':
            await funFeatures.wink(ctx);
            break;
            
        case 'smile':
            await funFeatures.smile(ctx);
            break;
            
        case 'smug':
            await funFeatures.smug(ctx);
            break;
            
        case 'blush':
            await funFeatures.blush(ctx);
            break;
            
        case 'cry':
            await funFeatures.cry(ctx);
            break;
            
        case 'dance':
            await funFeatures.dance(ctx);
            break;
            
        case 'cringe':
            await funFeatures.cringe(ctx);
            break;
            
        case 'highfive':
            await funFeatures.highFive(ctx);
            break;
            
        case 'handhold':
            await funFeatures.handHold(ctx);
            break;
            
        case 'nom':
            await funFeatures.nom(ctx);
            break;
            
        case 'bite':
            await funFeatures.bite(ctx);
            break;
            
        case 'glomp':
            await funFeatures.glomp(ctx);
            break;
            
        case 'happy':
            await funFeatures.happy(ctx);
            break;
            
        case 'lurk':
            await funFeatures.lurk(ctx);
            break;
            
        case 'nod':
            await funFeatures.nod(ctx);
            break;
            
        case 'nope':
            await funFeatures.nope(ctx);
            break;
            
        case 'peck':
            await funFeatures.peck(ctx);
            break;
            
        case 'yawn':
            await funFeatures.yawn(ctx);
            break;
            
        case 'thumbsup':
            await funFeatures.thumbsUp(ctx);
            break;
            
        case 'facepalm':
            await funFeatures.facePalm(ctx);
            break;
            
        case 'facedesk':
            await funFeatures.faceDesk(ctx);
            break;
            
        case 'thinking':
            await funFeatures.thinking(ctx);
            break;
            
        case 'shrug':
            await funFeatures.shrug(ctx);
            break;
            
        case 'tableflip':
            await funFeatures.tableFlip(ctx);
            break;
            
        case 'unflip':
            await funFeatures.unFlip(ctx);
            break;
            
        case 'sus':
            await funFeatures.sus(ctx);
            break;
            
        case 'bruh':
            await funFeatures.bruh(ctx);
            break;
            
        case 'oof':
            await funFeatures.oof(ctx);
            break;
            
        case 'rip':
            await funFeatures.rip(ctx);
            break;
            
        case 'f':
            await funFeatures.f(ctx);
            break;
            
        case 'clown':
            await funFeatures.clown(ctx);
            break;
            
        case 'simp':
            await funFeatures.simp(ctx);
            break;
            
        case 'horny':
            await funFeatures.horny(ctx);
            break;
            
        case 'gay':
            await funFeatures.gay(ctx);
            break;
            
        case 'lesbian':
            await funFeatures.lesbian(ctx);
            break;
            
        case 'bisexual':
            await funFeatures.bisexual(ctx);
            break;
            
        case 'transgender':
            await funFeatures.transgender(ctx);
            break;
            
        case 'pansexual':
            await funFeatures.pansexual(ctx);
            break;
            
        case 'asexual':
            await funFeatures.asexual(ctx);
            break;
            
        case 'nonbinary':
            await funFeatures.nonBinary(ctx);
            break;
            
        case 'genderfluid':
            await funFeatures.genderFluid(ctx);
            break;
            
        case 'demisexual':
            await funFeatures.demisexual(ctx);
            break;
            
        case 'lgbtq':
            await funFeatures.lgbtq(ctx);
            break;
            
        case 'pronouns':
            await funFeatures.pronouns(ctx);
            break;
            
        case 'roast':
            await funFeatures.roast(ctx);
            break;
            
        case 'compliment':
            await funFeatures.compliment(ctx);
            break;
            
        case 'pickupline':
            await funFeatures.pickupLine(ctx);
            break;
            
        case 'confession':
            await funFeatures.confession(ctx);
            break;
            
        case 'question':
            await funFeatures.question(ctx);
            break;
            
        case 'topic':
            await funFeatures.topic(ctx);
            break;
            
        case 'neverhaveiever':
        case 'nhie':
            await funFeatures.neverHaveIEver(ctx);
            break;
            
        case 'mostlikely':
            await funFeatures.mostLikely(ctx);
            break;
            
        case 'randomquestion':
            await funFeatures.randomQuestion(ctx);
            break;
            
        case 'icebreaker':
            await funFeatures.iceBreaker(ctx);
            break;
            
        case 'conversationstarter':
            await funFeatures.conversationStarter(ctx);
            break;
            
        case 'debate':
            await funFeatures.debate(ctx);
            break;
            
        case 'hot take':
            await funFeatures.hotTake(ctx);
            break;
            
        case 'unpopularopinion':
            await funFeatures.unpopularOpinion(ctx);
            break;
            
        case 'showerthought':
            await funFeatures.showerThought(ctx);
            break;
            
        case 'lifeprotip':
        case 'lpt':
            await funFeatures.lifeProTip(ctx);
            break;
            
        case 'yoprotip':
        case 'ypt':
            await funFeatures.YoProTip(ctx);
            break;
            
        case 'ilpt':
            await funFeatures.ILPT(ctx);
            break;
            
        case 'slpt':
            await funFeatures.SLPT(ctx);
            break;
            
        case 'ulpt':
            await funFeatures.ULPT(ctx);
            break;
            
        case 'elpt':
            await funFeatures.ELPT(ctx);
            break;
            
        case 'glpt':
            await funFeatures.GLPT(ctx);
            break;
            
        case 'blpt':
            await funFeatures.BLPT(ctx);
            break;
            
        case 'rlpt':
            await funFeatures.RLPT(ctx);
            break;
            
        case 'dlpt':
            await funFeatures.DLPT(ctx);
            break;
            
        case 'alpt':
            await funFeatures.ALPT(ctx);
            break;
            
        case 'nlpt':
            await funFeatures.NLPT(ctx);
            break;
            
        case 'olpt':
            await funFeatures.OLPT(ctx);
            break;
            
        case 'plpt':
            await funFeatures.PLPT(ctx);
            break;
            
        case 'qlpt':
            await funFeatures.QLPT(ctx);
            break;
            
        case 'wlpt':
            await funFeatures.WLPT(ctx);
            break;
            
        case 'elpt2':
            await funFeatures.ELPT2(ctx);
            break;
            
        case 'rlpt2':
            await funFeatures.RLPT2(ctx);
            break;
            
        case 'tlpt':
            await funFeatures.TLPT(ctx);
            break;
            
        case 'ylpt':
            await funFeatures.YLPT(ctx);
            break;
            
        case 'ulpt2':
            await funFeatures.ULPT2(ctx);
            break;
            
        case 'ilpt2':
            await funFeatures.ILPT2(ctx);
            break;
            
        case 'olpt2':
            await funFeatures.OLPT2(ctx);
            break;
            
        case 'plpt2':
            await funFeatures.PLPT2(ctx);
            break;
            
        case 'alpt2':
            await funFeatures.ALPT2(ctx);
            break;
            
        case 'slpt2':
            await funFeatures.SLPT2(ctx);
            break;
            
        case 'dlpt2':
            await funFeatures.DLPT2(ctx);
            break;
            
        case 'flpt':
            await funFeatures.FLPT(ctx);
            break;
            
        case 'glpt2':
            await funFeatures.GLPT2(ctx);
            break;
            
        case 'hlpt':
            await funFeatures.HLPT(ctx);
            break;
            
        case 'jlpt':
            await funFeatures.JLPT(ctx);
            break;
            
        case 'klpt':
            await funFeatures.KLPT(ctx);
            break;
            
        case 'llpt':
            await funFeatures.LLPT(ctx);
            break;
            
        case 'zlpt':
            await funFeatures.ZLPT(ctx);
            break;
            
        case 'xlpt':
            await funFeatures.XLPT(ctx);
            break;
            
        case 'clpt2':
            await funFeatures.CLPT2(ctx);
            break;
            
        case 'vlpt':
            await funFeatures.VLPT(ctx);
            break;
            
        case 'blpt2':
            await funFeatures.BLPT2(ctx);
            break;
            
        case 'nlpt2':
            await funFeatures.NLPT2(ctx);
            break;
            
        case 'mlpt':
            await funFeatures.MLPT(ctx);
            break;

        // ═══════════════════════════════════════════════════════════
        // DEFAULT - UNKNOWN COMMAND
        // ═══════════════════════════════════════════════════════════
        default:
            if (command) {
                await sock.sendMessage(chatId, {
                    text: `❓ Unknown command: *${command}*\n\nType *.menu* to see all available commands.`,
                    contextInfo: {
                        externalAdReply: {
                            title: 'ACE♡ Bot',
                            body: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
                            showAdAttribution: true
                        }
                    }
                });
            }
            break;
    }
}

/**
 * Send startup message to owner
 */
async function sendStartupMessage() {
    const startupMsg = `🤖 *${config.botName}* is now online!\n\n` +
        `📅 Date: ${moment().format('DD/MM/YYYY')}\n` +
        `⏰ Time: ${moment().format('HH:mm:ss')}\n` +
        `🌍 Timezone: ${config.timezone}\n\n` +
        `✅ Bot Status: *Active*\n` +
        `📊 Commands: *200+*\n` +
        `🔧 Features: *Loaded*\n\n` +
        `📢 Channel: ${config.channelLink}\n` +
        `💬 Support: ${config.groupLink}`;
    
    try {
        await sock.sendMessage(config.ownerNumber + '@s.whatsapp.net', { text: startupMsg });
    } catch (e) {
        console.log(chalk.yellow('⚠️ Could not send startup message to owner'));
    }
}

// Start the bot
startBot().catch(err => {
    console.error(chalk.red('Fatal error:'), err);
    process.exit(1);
});

// Handle process termination
process.on('SIGINT', () => {
    console.log(chalk.yellow('\n👋 Shutting down ACE♡ Bot...'));
    if (sock) {
        sock.end();
    }
    process.exit(0);
});

process.on('uncaughtException', (err) => {
    console.error(chalk.red('Uncaught Exception:'), err);
});

process.on('unhandledRejection', (err) => {
    console.error(chalk.red('Unhandled Rejection:'), err);
});

module.exports = { sock, config };
