# 🤖 ACE♡ - Ultimate WhatsApp Bot

**Version 3.0** | ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】

---

## ✨ Features

- ✅ **200+ Commands** - Comprehensive menu system
- ✅ **Pairing Code Connection** - No QR code needed!
- ✅ **Human-like Auto Reply** - Natural conversations with typing delays
- ✅ **Sticker Watermark** - All stickers carry your brand
- ✅ **70+ Anti-Features** - Advanced group protection
- ✅ **AI Integration** - ChatGPT, Bard, Claude & more
- ✅ **Downloaders** - YouTube, TikTok, Instagram, etc.
- ✅ **Games & Economy** - Fun RPG system
- ✅ **Group Management** - Full admin controls
- ✅ **Free to Use** - No premium required!

---

## 📋 Table of Contents

- [Installation](#installation)
- [Setup](#setup)
- [Usage](#usage)
- [Commands](#commands)
- [Anti-Features](#anti-features)
- [Configuration](#configuration)
- [Troubleshooting](#troubleshooting)

---

## 🚀 Installation

### Prerequisites

- Node.js v16+ 
- npm or yarn
- Git (optional)

### Step 1: Download the Bot

```bash
# Clone or download the bot files
git clone <repository-url>
cd ACE-WhatsApp-Bot
```

### Step 2: Install Dependencies

```bash
npm install
```

Or if you have yarn:

```bash
yarn install
```

### Step 3: Configure the Bot

Edit `ace.js` and update the configuration:

```javascript
const config = {
    botName: 'ACE♡',
    ownerName: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
    ownerNumber: '234XXXXXXXXXX', // <-- REPLACE WITH YOUR NUMBER
    prefix: ['.', '!', '#', '/'],
    channelLink: 'https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i',
    groupLink: 'https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo',
    // ... rest of config
};
```

---

## ▶️ Setup

### Method 1: Pairing Code (Recommended)

1. **Start the bot:**
```bash
npm start
```

2. **Enter your WhatsApp number** when prompted (with country code):
```
📱 Pairing Code Connection

Enter your WhatsApp number with country code (e.g., 2348012345678):
Your Number: 234XXXXXXXXXX
```

3. **Get pairing code** displayed on screen

4. **Link your device:**
   - Open WhatsApp on your phone
   - Go to Settings → Linked Devices
   - Tap "Link with Phone Number Instead"
   - Enter the pairing code shown

5. **Done!** The bot is now connected!

### Method 2: Using Termux (Android)

```bash
# Update packages
pkg update && pkg upgrade

# Install Node.js
pkg install nodejs

# Install Git
pkg install git

# Clone repository
git clone <repository-url>
cd ACE-WhatsApp-Bot

# Install dependencies
npm install

# Start bot
npm start
```

### Method 3: Using VPS/Cloud (24/7)

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Clone and setup
git clone <repository-url>
cd ACE-WhatsApp-Bot
npm install

# Start with PM2
pm2 start ace.js --name ACE-Bot
pm2 save
pm2 startup
```

---

## 🎮 Usage

### Basic Commands

| Command | Description |
|---------|-------------|
| `.menu` | Show all menus |
| `.help` | Show help |
| `.allmenu` | Show all commands |

### Menu Categories

| Menu | Command |
|------|---------|
| Owner Menu | `.ownermenu` |
| Group Menu | `.groupmenu` |
| Anti-Features | `.antimenu` |
| Download Menu | `.downloadmenu` |
| Sticker Menu | `.stickermenu` |
| AI Menu | `.aimenu` |
| Fun Menu | `.funmenu` |
| Game Menu | `.gamemenu` |
| Tools Menu | `.toolsmenu` |
| Islamic Menu | `.islamicmenu` |
| Economy Menu | `.economymenu` |
| Info Menu | `.infomenu` |

---

## 🛡️ Anti-Features

### Link & Spam Control
- `.antilink on/off` - Block links
- `.antilinkhard on/off` - Instant link removal
- `.antispam on/off` - Anti-spam protection
- `.spamlimit <number>` - Set spam limit
- `.antiflood on/off` - Flood protection
- `.antibot on/off` - Block other bots
- `.antiforward on/off` - Block forwards

### Bad Words & Toxicity
- `.antibadword on/off` - Block bad words
- `.badword add <word>` - Add bad word
- `.badword remove <word>` - Remove bad word
- `.badwordlist` - List bad words
- `.antitoxic on/off` - Toxicity filter
- `.antinsfw on/off` - NSFW filter
- `.antiswear on/off` - Swear filter

### Group Security
- `.antifake on/off` - Block fake numbers
- `.antiforeign on/off` - Block foreign numbers
- `.antiprivate on/off` - Block private DMs
- `.antitagall on/off` - Block @all
- `.antimention on/off` - Limit mentions
- `.antilurker on/off` - Remove inactive users
- `.antiraid on/off` - Raid protection

### Media Control
- `.antiimage on/off` - Block images
- `.antivideo on/off` - Block videos
- `.antiaudio on/off` - Block audio
- `.antigif on/off` - Block GIFs
- `.antisticker on/off` - Block stickers
- `.antidocument on/off` - Block documents
- `.antiviewonce on/off` - Block view-once

### Privacy & Protection
- `.antidelete on/off` - Recover deleted messages 👀
- `.antiedit on/off` - Track edited messages
- `.antihack on/off` - Hack protection
- `.antiphishing on/off` - Phishing protection
- `.antiscam on/off` - Scam protection
- `.antifraud on/off` - Fraud protection

### Fun Anti Features (Unique!)
- `.antidry on/off` - "Omo you dey dry chat 😭"
- `.antighost on/off` - Expose ghost readers 👻
- `.antiflex on/off` - "Calm down Dangote 😭"
- `.antirizz on/off` - Block excessive flirting
- `.antinoise on/off` - Filter nonsense
- `.antiboring on/off` - Revive dead chats
- `.antidrama on/off` - Detect arguments
- `.antisleep on/off` - "Everybody don kpai? 😭"
- `.antistatusviewer on/off` - Expose stalkers 👀

---

## ⚙️ Configuration

### Bot Settings

Edit `config` object in `ace.js`:

```javascript
const config = {
    // Basic Info
    botName: 'ACE♡',
    ownerName: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
    ownerNumber: '234XXXXXXXXXX',
    
    // Prefixes
    prefix: ['.', '!', '#', '/'],
    
    // Links
    channelLink: 'https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i',
    groupLink: 'https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo',
    
    // Features
    autoRead: true,
    autoTyping: true,
    autoRecord: false,
    antiCall: true,
    antiSpam: true,
    antiLink: true,
    antiBadword: true,
    antiDelete: true,
    antiEdit: true,
    
    // Limits
    spamLimit: 10,
    floodInterval: 5000,
    
    // Sticker
    stickerWatermark: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】',
    stickerPack: 'ACE♡ Stickers',
    stickerAuthor: '⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】'
};
```

---

## 📁 File Structure

```
ACE-WhatsApp-Bot/
├── ace.js                 # Main bot file
├── package.json           # Dependencies
├── README.md              # This file
├── lib/                   # Modules
│   ├── menu.js           # Menu system
│   ├── anti-features.js  # Anti-features
│   ├── sticker.js        # Sticker maker
│   ├── human-reply.js    # Auto-reply
│   ├── database.js       # Database
│   ├── downloader.js     # Downloaders
│   ├── ai-features.js    # AI integration
│   ├── fun.js            # Fun commands
│   ├── group.js          # Group features
│   ├── tools.js          # Utility tools
│   ├── games.js          # Games
│   ├── owner.js          # Owner commands
│   ├── islamic.js        # Islamic features
│   ├── nsfw.js           # NSFW (18+)
│   ├── economy.js        # Economy system
│   └── welcome.js        # Welcome/Goodbye
├── database/             # Database files
│   └── store.json
├── media/                # Media storage
└── temp/                 # Temp files
```

---

## 🔧 Troubleshooting

### Common Issues

#### 1. "Module not found" Error
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

#### 2. Connection Failed
```bash
# Delete session and reconnect
rm -rf ACE-Session
npm start
```

#### 3. Pairing Code Not Working
- Make sure you enter number with country code (e.g., 234...)
- Don't include + or spaces
- Try again after a few minutes

#### 4. Bot Crashes
```bash
# Check logs
pm2 logs ACE-Bot

# Restart
pm2 restart ACE-Bot
```

#### 5. Sticker Not Working
```bash
# Install ffmpeg
# Ubuntu/Debian:
sudo apt-get install ffmpeg

# Termux:
pkg install ffmpeg
```

---

## 🌟 Advanced Features

### Human-like Auto Reply

The bot automatically replies to DMs with human-like responses:
- Typing delays for realism
- Context-aware replies
- Random emoji usage
- Occasional sticker sends

### Sticker Watermark

All stickers created by the bot automatically include:
- Pack name: "ACE♡ Stickers"
- Author: "⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】"

### Anti-Delete

Deleted messages are automatically recovered and reposted with:
- Original content
- Sender information
- Timestamp

---

## 📞 Support

- **WhatsApp Channel:** https://whatsapp.com/channel/0029VbAHkX60G0XpupxKuv1i
- **Support Group:** https://chat.whatsapp.com/J4G0o9M4HvS0KXsDKVrvWo

---

## 📝 License

MIT License - Free to use and modify!

---

## 🙏 Credits

- **Developer:** ⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】
- **Library:** @whiskeysockets/baileys
- **Community:** WhatsApp Bot Developers

---

**Enjoy using ACE♡ Bot!** 🚀

⛧᭄ 𝐋𝐎𝐑𝐃 𝐀𝐂𝐄♞᭄【ᵠ】
