# 🚀 DeepSeek AI Ultimate - Quick Start Guide

## ⚡ Get Started in 3 Minutes!

---

## 📥 Step 1: Install (1 minute)

### Option A: Using Setup Script (Recommended)
```bash
python setup.py
```

### Option B: Manual Installation
```bash
pip install requests pycryptodome rich pywhatkit qrcode[pil] pillow wikipedia googlesearch-python
```

---

## ▶️ Step 2: Run (30 seconds)

```bash
python enhanced_deepseek_bot.py
```

---

## 🎯 Step 3: Start Using (Instant!)

### Main Menu Options:
```
[1] 🤖 AI Chat - Just type your message!
[2] 💬 WhatsApp Bot (Premium)
[3] 🛠️ Utilities
[4] 📚 Information
[5] ⚙️ System Tools
[6] 💎 Premium Upgrade
[7] ❓ Help
[8] 🚪 Exit
```

---

## 💬 Quick Commands

### Chat with AI
```
Just type: Hello, how are you?
Or use: /chat Tell me a joke
```

### Calculate
```
/calc 5+5*2
```

### Check Weather
```
/weather Lagos
```

### Generate Password
```
/password 16
```

### Search Wikipedia
```
/wiki Python programming
```

---

## 💎 Upgrade to Premium (₦2,000)

### Why Upgrade?
✅ WhatsApp Bot Integration  
✅ Unlimited AI Messages  
✅ Priority Support  
✅ All Advanced Tools  

### How to Upgrade:
1. **Pay ₦2,000** to:
   - Bank: First Bank
   - Account: 3229976040
   - Name: Bhadmus Oluwadamilare Emmanuel

2. **Contact @LordAceTech** on Telegram with proof

3. **Receive your premium code**

4. **Activate** using `/verify` command

---

## 📱 WhatsApp Bot (Premium Feature)

### Sending Messages:
1. Select option `[2]` or type `/whatsapp`
2. Choose "Send Message"
3. Enter phone number (+234...)
4. Type your message
5. Send instantly or schedule!

### Requirements:
- Must be logged into WhatsApp Web
- Computer must stay on for scheduled messages

---

## 🆘 Need Help?

### Commands:
- `/help` - Show all commands
- `/menu` - Show main menu
- `/about` - About this bot
- `/support` - Get support info

### Contact:
- Telegram Channel: @CyberVault01
- Developer: @LordAceTech
- URL: https://t.me/+hb6tjU3R98c0MGVk

---

## 🎉 You're All Set!

Enjoy using **DeepSeek AI Ultimate**! 🚀

For detailed documentation, see `README.md`
