# 🤖 DeepSeek AI Ultimate - Enhanced Chat Bot

**Version 2.0** | Developer: @LordAceTech | Telegram: @CyberVault01

---

## 📋 Table of Contents
- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Premium Features](#premium-features)
- [WhatsApp Integration](#whatsapp-integration)
- [Available Commands](#available-commands)
- [Payment Details](#payment-details)
- [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

DeepSeek AI Ultimate is an enhanced Python-based chatbot that combines the power of DeepSeek AI models with additional utility tools and WhatsApp integration. This upgraded version offers a comprehensive suite of features including AI chat, system tools, information retrieval, and premium WhatsApp bot capabilities.

---

## ✨ Features

### 🤖 AI Chat Features
- **18 DeepSeek Models** including V1, V2, V2.5, V3, R1, Coder, Prover, and more
- **Interactive Chat Mode** for seamless conversations
- **Model Selection** - Choose your preferred AI model
- **Session Management** with automatic reconnection

### 💬 WhatsApp Bot (Premium)
- Send text messages instantly or schedule for later
- Send images with captions
- Message logging and history
- Support for international phone numbers

### 🛠️ Utility Tools
- **Calculator** - Evaluate mathematical expressions
- **Weather Checker** - Get current weather for any city
- **Currency Converter** - Convert between currencies
- **QR Code Generator** - Create QR codes for any data
- **Password Generator** - Generate secure passwords

### 📚 Information Tools
- **Wikipedia Search** - Quick knowledge lookup
- **Google Search** - Search the web directly
- **Dictionary** - Word definitions (coming soon)
- **News Headlines** - Latest news (coming soon)

### ⚙️ System Tools
- **System Information** - View system specs
- **File Organizer** - Organize files by extension
- **Disk Usage** - Storage analysis (coming soon)

---

## 📦 Installation

### Prerequisites
- Python 3.7 or higher
- pip package manager

### Step 1: Install Dependencies

```bash
# Install all required packages
pip install -r requirements.txt

# Or install individually
pip install requests pycryptodome rich pywhatkit qrcode[pil] wikipedia googlesearch-python pillow
```

### Step 2: Download the Script

Save `enhanced_deepseek_bot.py` to your desired directory.

### Step 3: Run the Bot

```bash
python enhanced_deepseek_bot.py
```

---

## 🚀 Usage

### Starting the Bot

```bash
python enhanced_deepseek_bot.py
```

### First Run
- On first launch, you'll be redirected to the Telegram channel
- Join @CyberVault01 for updates and support

### Main Menu Options

```
[1] 🤖 AI Chat - Chat with DeepSeek AI
[2] 💬 WhatsApp Bot (Premium) - Send WhatsApp messages
[3] 🛠️ Utilities - Calculator, QR, Password generator
[4] 📚 Information - Wikipedia, News, Search
[5] ⚙️ System Tools - System info, File organizer
[6] 💎 Premium - Upgrade to premium
[7] ❓ Help - Show all commands
[8] 🚪 Exit - Close application
```

---

## 💎 Premium Features

### What You Get with Premium

✅ **WhatsApp Bot Integration**
- Send unlimited WhatsApp messages
- Schedule messages for later delivery
- Send images and media
- Full message history and logging

✅ **Unlimited AI Messages**
- No usage limits on AI chat
- Access to all 18 AI models
- Priority response times

✅ **Advanced Tools**
- All utility tools unlocked
- System management features
- File organization tools

✅ **Priority Support**
- Direct contact with developer
- Priority bug fixes
- Feature requests accepted

✅ **No Advertisements**
- Clean, ad-free experience

---

## 📱 WhatsApp Integration

### Setting Up WhatsApp Bot

1. **Upgrade to Premium** - Pay ₦2,000 to activate
2. **Get Your Code** - Contact @LordAceTech on Telegram after payment
3. **Verify Code** - Use `/verify` command to activate
4. **Start Using** - Access WhatsApp features via menu

### Sending Messages

```
1. Select "WhatsApp Bot" from menu
2. Choose "Send Message"
3. Enter phone number (with country code, e.g., +2348012345678)
4. Type your message
5. Choose to send instantly or schedule
```

### Scheduling Messages

You can schedule messages to be sent at a specific time:
- Enter hour (24-hour format)
- Enter minute
- The message will be sent automatically

**Note:** Your computer must be on and connected to internet at the scheduled time.

---

## 📖 Available Commands

### AI Chat Commands
| Command | Description |
|---------|-------------|
| `/chat [message]` | Start chatting with AI |
| `/models` | Show available AI models |
| `/clear` | Clear screen |

### WhatsApp Commands (Premium)
| Command | Description |
|---------|-------------|
| `/whatsapp` | Open WhatsApp menu |
| `/wasend` | Send WhatsApp message |
| `/walog` | View message log |
| `/wastatus` | Check WhatsApp status |

### Utility Commands
| Command | Description | Example |
|---------|-------------|---------|
| `/calc [expr]` | Calculator | `/calc 5+5*2` |
| `/weather [city]` | Weather info | `/weather Lagos` |
| `/convert` | Currency converter | Interactive |
| `/qr [data]` | Generate QR code | `/qr https://example.com` |
| `/password [len]` | Generate password | `/password 16` |

### Information Commands
| Command | Description |
|---------|-------------|
| `/wiki [query]` | Wikipedia search |
| `/search [query]` | Google search |
| `/define [word]` | Dictionary lookup |

### System Commands
| Command | Description |
|---------|-------------|
| `/sysinfo` | System information |
| `/organize` | Organize files by type |

### Premium Commands
| Command | Description |
|---------|-------------|
| `/premium` | Show premium info |
| `/verify` | Verify premium code |
| `/support` | Get support info |

### General Commands
| Command | Description |
|---------|-------------|
| `/help` | Show help menu |
| `/menu` | Show main menu |
| `/about` | About this bot |
| `/exit` | Exit program |

---

## 💳 Payment Details

### Premium Upgrade: ₦2,000 Only

| Detail | Information |
|--------|-------------|
| **Amount** | ₦2,000 NGN |
| **Bank** | First Bank of Nigeria |
| **Account Number** | 3229976040 |
| **Account Name** | Bhadmus Oluwadamilare Emmanuel |

### How to Upgrade

1. **Make Payment** - Transfer ₦2,000 to the account above
2. **Take Screenshot** - Save proof of payment
3. **Contact Developer** - Message @LordAceTech on Telegram
4. **Receive Code** - Get your premium activation code
5. **Activate** - Use `/verify` command and enter your code

### After Payment

Contact on Telegram: **@LordAceTech**
Telegram Channel: **@CyberVault01**
Channel URL: https://t.me/+hb6tjU3R98c0MGVk

---

## 🔧 Troubleshooting

### Common Issues

#### 1. Module Not Found Error
```bash
# Solution: Install missing packages
pip install -r requirements.txt
```

#### 2. WhatsApp Not Working
```bash
# Install pywhatkit
pip install pywhatkit

# Make sure you're logged into WhatsApp Web
# Open web.whatsapp.com and scan QR code
```

#### 3. AI Not Responding
- Check internet connection
- The external service might be temporarily down
- Try again after a few minutes

#### 4. QR Code Generation Fails
```bash
# Install qrcode with pillow
pip install qrcode[pil]
```

#### 5. Wikipedia Search Not Working
```bash
# Install wikipedia
pip install wikipedia
```

### Getting Help

1. Check the `/help` command in the bot
2. Join our Telegram channel: @CyberVault01
3. Contact developer: @LordAceTech

---

## ⚠️ Important Notes

1. **WhatsApp Web Required** - For WhatsApp features, you must be logged into WhatsApp Web
2. **Internet Connection** - Required for all AI and online features
3. **Computer Must Stay On** - For scheduled WhatsApp messages
4. **Phone Number Format** - Always include country code (e.g., +234 for Nigeria)
5. **Premium Codes** - Each code can only be used once

---

## 📝 Sample Configuration

The bot creates two configuration files:

### bot_config.json
```json
{
    "premium": false,
    "verified_code": null,
    "whatsapp_contacts": [],
    "message_history": [],
    "preferred_model": "DeepSeek-V3",
    "theme": "default",
    "first_run": false
}
```

### premium_codes.json
```json
{
    "DSK-2024-VIP-001": false,
    "DSK-2024-VIP-002": false
}
```

---

## 🔄 Updates & Support

### Stay Updated
- Join Telegram: https://t.me/+hb6tjU3R98c0MGVk
- Follow @CyberVault01 for latest updates
- Contact @LordAceTech for support

### Feature Requests
Premium users can request custom features by contacting the developer.

---

## 📜 License

This project is for educational and personal use. Premium features require payment as specified.

---

## 🙏 Credits

- **Developer:** @LordAceTech
- **Telegram Channel:** @CyberVault01
- **AI Models:** DeepSeek AI
- **Libraries:** Rich, PyWhatKit, Requests, PyCryptodome

---

**Enjoy using DeepSeek AI Ultimate! 🚀**

For any questions or support, contact us on Telegram!
