#!/usr/bin/env python3
"""
Premium Code Generator for DeepSeek AI Ultimate
Developer: @LordAceTech | Telegram: @CyberVault01
"""

import random
import string
import json
from datetime import datetime

def generate_code(prefix="DSK", year=None, batch="VIP"):
    """Generate a premium activation code"""
    if year is None:
        year = datetime.now().year
    
    # Generate random 3-digit number
    number = ''.join(random.choices(string.digits, k=3))
    
    # Format: DSK-2024-VIP-001
    code = f"{prefix}-{year}-{batch}-{number}"
    return code

def generate_codes(count=10, existing_codes=None):
    """Generate multiple unique premium codes"""
    if existing_codes is None:
        existing_codes = set()
    
    codes = {}
    attempts = 0
    max_attempts = count * 10
    
    while len(codes) < count and attempts < max_attempts:
        code = generate_code()
        if code not in existing_codes and code not in codes:
            codes[code] = False  # False = unused
        attempts += 1
    
    return codes

def save_codes_to_file(codes, filename="premium_codes_new.json"):
    """Save generated codes to JSON file"""
    data = {
        "_comment": "DeepSeek AI Ultimate - Premium Activation Codes",
        "_generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "_developer": "@LordAceTech",
        "_telegram": "@CyberVault01",
        "_payment_info": {
            "amount": "2000 NGN",
            "account_number": "3229976040",
            "bank": "First Bank",
            "account_name": "Bhadmus Oluwadamilare Emmanuel"
        },
        "codes": codes
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    
    return filename

def print_codes(codes):
    """Print codes in a nice format"""
    print("\n" + "="*60)
    print("🎫 GENERATED PREMIUM CODES")
    print("="*60)
    print(f"\nTotal codes: {len(codes)}\n")
    
    for i, code in enumerate(sorted(codes.keys()), 1):
        status = "🟢 Available" if not codes[code] else "🔴 Used"
        print(f"{i:3}. {code} - {status}")
    
    print("\n" + "="*60)
    print("💰 Sell each code for ₦2,000 NGN")
    print("🏦 Payment to: 3229976040 (First Bank)")
    print("="*60 + "\n")

def main():
    print("""
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║   💎 PREMIUM CODE GENERATOR 💎                                ║
    ║                                                               ║
    ║   Developer: @LordAceTech                                     ║
    ║   Telegram: @CyberVault01                                     ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """)
    
    try:
        count = int(input("How many codes to generate? (default: 10): ") or "10")
    except:
        count = 10
    
    # Load existing codes if any
    existing_codes = set()
    try:
        with open("premium_codes.json", 'r') as f:
            data = json.load(f)
            existing_codes = set(data.get("codes", {}).keys())
    except:
        pass
    
    # Generate new codes
    codes = generate_codes(count, existing_codes)
    
    # Print codes
    print_codes(codes)
    
    # Save to file
    filename = save_codes_to_file(codes)
    print(f"✅ Codes saved to: {filename}")
    
    # Option to merge with existing
    if existing_codes:
        merge = input("\nMerge with existing codes? (y/n): ").lower()
        if merge == 'y':
            with open("premium_codes.json", 'r') as f:
                data = json.load(f)
                data["codes"].update(codes)
            
            with open("premium_codes.json", 'w') as f:
                json.dump(data, f, indent=4)
            
            print("✅ Merged with existing codes!")

if __name__ == "__main__":
    main()
