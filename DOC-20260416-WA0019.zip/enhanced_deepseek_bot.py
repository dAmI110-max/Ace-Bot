#!/usr/bin/env python3
"""
Enhanced DeepSeek AI Chat Interface with Multi-Functionality & WhatsApp Bot Integration
Developer: @LordAceTech
Telegram: @CyberVault01
Premium Payment: 2,000 NGN to 3229976040 (First Bank - Bhadmus Oluwadamilare Emmanuel)
"""

import requests
import re
import time
import webbrowser
import os
import sys
import json
import random
import string
import hashlib
import datetime
import subprocess
import platform
from pathlib import Path
from urllib.parse import quote
from Crypto.Cipher import AES
from rich import print
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.console import Console
from rich.table import Table
from rich import box
from rich.align import Align
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.syntax import Syntax
from rich.markdown import Markdown

# Try importing optional dependencies
try:
    import pywhatkit
    PYWHATKIT_AVAILABLE = True
except ImportError:
    PYWHATKIT_AVAILABLE = False

try:
    import qrcode
    QR_AVAILABLE = True
except ImportError:
    QR_AVAILABLE = False

try:
    import wikipedia
    WIKIPEDIA_AVAILABLE = True
except ImportError:
    WIKIPEDIA_AVAILABLE = False

try:
    from googlesearch import search
    GOOGLE_AVAILABLE = True
except ImportError:
    GOOGLE_AVAILABLE = False

console = Console()

# Configuration
CONFIG_FILE = "bot_config.json"
PREMIUM_CODES_FILE = "premium_codes.json"
TELEGRAM_URL = "https://t.me/+hb6tjU3R98c0MGVk"
DEVELOPER = "@LordAceTech"
TELEGRAM_CHANNEL = "@CyberVault01"
PAYMENT_DETAILS = {
    "amount": "2,000 NGN",
    "account_number": "3229976040",
    "bank": "First Bank",
    "account_name": "Bhadmus Oluwadamilare Emmanuel"
}

# DeepSeek Models
MODELS = [
    "DeepSeek-V1", "DeepSeek-V2", "DeepSeek-V2.5", "DeepSeek-V3", "DeepSeek-V3-0324",
    "DeepSeek-V3.1", "DeepSeek-V3.2", "DeepSeek-R1", "DeepSeek-R1-0528", "DeepSeek-R1-Distill",
    "DeepSeek-Prover-V1", "DeepSeek-Prover-V1.5", "DeepSeek-Prover-V2", "DeepSeek-VL",
    "DeepSeek-Coder", "DeepSeek-Coder-V2", "DeepSeek-Coder-6.7B-base", "DeepSeek-Coder-6.7B-instruct"
]

# Command categories
COMMANDS = {
    "AI Chat": ["/chat", "/models", "/clear"],
    "WhatsApp": ["/whatsapp", "/wastatus", "/walog"],
    "Utilities": ["/weather", "/calc", "/convert", "/qr", "/password"],
    "Information": ["/news", "/wiki", "/search", "/define"],
    "System": ["/sysinfo", "/files", "/organize"],
    "Premium": ["/premium", "/verify", "/support"],
    "General": ["/help", "/menu", "/exit", "/about"]
}


def load_config():
    """Load or create configuration file"""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {
        "premium": False,
        "verified_code": None,
        "whatsapp_contacts": [],
        "message_history": [],
        "preferred_model": "DeepSeek-V3",
        "theme": "default",
        "first_run": True
    }


def save_config(config):
    """Save configuration to file"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=4)


def load_premium_codes():
    """Load valid premium codes (in production, this should be server-side)"""
    if os.path.exists(PREMIUM_CODES_FILE):
        with open(PREMIUM_CODES_FILE, 'r') as f:
            return json.load(f)
    # Generate some sample codes (in real scenario, these would be pre-generated)
    return {
        "DSK-2024-VIP-001": False,
        "DSK-2024-VIP-002": False,
        "DSK-2024-VIP-003": False
    }


def save_premium_codes(codes):
    """Save premium codes"""
    with open(PREMIUM_CODES_FILE, 'w') as f:
        json.dump(codes, f, indent=4)


def display_banner():
    """Display main banner"""
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║   🤖 WELCOME TO DEEPSEEK CHAT AI - ULTIMATE EDITION 🤖        ║
    ║                                                               ║
    ║   📢 Join Our Telegram Channel For Updates & Support!         ║
    ║      Telegram: @CyberVault01                                  ║
    ║      Developer: @LordAceTech                                  ║
    ║                                                               ║
    ║   💎 PREMIUM FEATURES AVAILABLE!                              ║
    ║      WhatsApp Bot Integration - Only 2,000 NGN                ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    
    print(Panel.fit(
        Align.center(Text(banner, style="bold cyan")),
        border_style="bright_magenta",
        title="[bold yellow]⚡ DEEPSEEK AI ULTIMATE ⚡[/bold yellow]",
        subtitle="[bold green]🚀 Version 2.0 🚀[/bold green]"
    ))


def redirect_to_telegram():
    """Redirect user to Telegram channel"""
    print("\n[bold yellow]🔔 Opening Telegram channel in 3 seconds...[/bold yellow]")
    for i in range(3, 0, -1):
        print(f"[bold cyan]⏳ {i}...[/bold cyan]", end='\r')
        time.sleep(1)
    
    try:
        webbrowser.open(TELEGRAM_URL)
        print("\n[bold green]✅ Telegram channel opened! Please join for updates.[/bold green]")
    except:
        print(f"\n[bold red]⚠️ Please manually visit:[/bold red] [link={TELEGRAM_URL}]{TELEGRAM_URL}[/link]")
    
    time.sleep(2)


def show_payment_info():
    """Display premium payment information"""
    payment_text = f"""
[bold cyan]💎 UPGRADE TO PREMIUM 💎[/bold cyan]

[bold white]Unlock WhatsApp Bot Integration & Exclusive Features![/bold white]

[bold yellow]Payment Details:[/bold yellow]
💰 Amount: [bold green]{PAYMENT_DETAILS['amount']}[/bold green]
🏦 Bank: [bold white]{PAYMENT_DETAILS['bank']}[/bold white]
📱 Account Number: [bold cyan]{PAYMENT_DETAILS['account_number']}[/bold cyan]
👤 Account Name: [bold white]{PAYMENT_DETAILS['account_name']}[/bold white]

[bold magenta]After payment, contact @LordAceTech on Telegram with proof of payment
to receive your premium activation code.[/bold magenta]

[bold green]Premium Benefits:[/bold green]
✅ WhatsApp Bot Integration
✅ Unlimited AI Messages
✅ Priority Support
✅ Advanced Tools Access
✅ Custom Model Selection
✅ No Ads
    """
    
    print(Panel.fit(
        payment_text,
        border_style="bright_yellow",
        title="[bold cyan]💎 PREMIUM UPGRADE 💎[/bold cyan]"
    ))


def verify_premium_code(config):
    """Verify premium activation code"""
    codes = load_premium_codes()
    
    print("\n[bold cyan]🔐 Enter your premium activation code:[/bold cyan]")
    print("[dim](Contact @LordAceTech on Telegram after payment to get your code)[/dim]\n")
    
    code = Prompt.ask("[bold yellow]Premium Code[/bold yellow]").strip().upper()
    
    if code in codes:
        if not codes[code]:  # If code not used
            codes[code] = True
            save_premium_codes(codes)
            config["premium"] = True
            config["verified_code"] = code
            save_config(config)
            print("\n[bold green]✅ Premium activated successfully![/bold green]")
            print("[bold cyan]🎉 You now have access to all premium features including WhatsApp Bot![/bold cyan]\n")
            return True
        else:
            print("\n[bold red]❌ This code has already been used![/bold red]\n")
    else:
        print("\n[bold red]❌ Invalid premium code![/bold red]")
        print("[bold yellow]💡 Please make payment to:[/bold yellow]")
        show_payment_info()
    return False


def check_premium_status(config):
    """Check if user has premium access"""
    if not config.get("premium", False):
        print("\n[bold red]⚠️ This is a PREMIUM feature![/bold red]")
        show_payment_info()
        
        choice = Prompt.ask(
            "\n[bold cyan]Do you have a premium code?[/bold cyan]",
            choices=["y", "n"],
            default="n"
        )
        
        if choice.lower() == "y":
            return verify_premium_code(config)
        return False
    return True


class DeepSeekAI:
    """DeepSeek AI Handler"""
    def __init__(self):
        self.session = None
        self.model = "DeepSeek-V3"
        self.initialized = False
        self.message_count = 0
    
    def initialize(self):
        """Initialize AI session"""
        try:
            self.session = requests.Session()
            self.session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Android 12; Mobile; rv:97.0) Gecko/97.0 Firefox/97.0'
            })
            
            # Get encryption keys
            r = self.session.get('https://asmodeus.free.nf/', timeout=10)
            nums = re.findall(r'toNumbers\("([a-f0-9]+)"\)', r.text)
            
            if len(nums) >= 3:
                key, iv, data = [bytes.fromhex(n) for n in nums[:3]]
                decrypted = AES.new(key, AES.MODE_CBC, iv).decrypt(data).hex()
                self.session.cookies.set('__test', decrypted, domain='asmodeus.free.nf')
                self.session.get('https://asmodeus.free.nf/index.php?i=1', timeout=10)
            
            self.initialized = True
            return True
        except Exception as e:
            print(f"[bold red]❌ AI Initialization Error: {e}[/bold red]")
            return False
    
    def chat(self, message):
        """Send message to AI and get response"""
        if not self.initialized:
            if not self.initialize():
                return "⚠️ AI service temporarily unavailable. Please try again later."
        
        try:
            r = self.session.post(
                'https://asmodeus.free.nf/deepseek.php',
                params={'i': '1'},
                data={'model': self.model, 'question': message},
                timeout=30
            )
            
            reply = re.search(r'<div class="response-content">(.*?)</div>', r.text, re.DOTALL)
            if reply:
                response = reply.group(1).strip()
                # Clean HTML tags
                response = re.sub(r'<[^>]+>', '', response)
                self.message_count += 1
                return response
            return "⚠️ No response received from AI"
        except requests.exceptions.Timeout:
            return "⏱️ Request timed out. Please try again."
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    def set_model(self, model_name):
        """Set AI model"""
        if model_name in MODELS:
            self.model = model_name
            return True
        return False


class WhatsAppBot:
    """WhatsApp Integration Handler"""
    def __init__(self):
        self.enabled = PYWHATKIT_AVAILABLE
        self.message_log = []
    
    def check_status(self):
        """Check WhatsApp integration status"""
        if not self.enabled:
            return "[bold red]❌ WhatsApp module not installed. Run: pip install pywhatkit[/bold red]"
        return "[bold green]✅ WhatsApp integration ready![/bold green]"
    
    def send_message(self, phone, message, scheduled_time=None):
        """Send WhatsApp message"""
        if not self.enabled:
            return False, "pywhatkit not installed. Run: pip install pywhatkit"
        
        try:
            # Clean phone number
            phone = re.sub(r'[^0-9]', '', phone)
            if not phone.startswith('+'):
                phone = '+' + phone
            
            if scheduled_time:
                hour, minute = scheduled_time
                pywhatkit.sendwhatmsg(phone, message, hour, minute)
            else:
                pywhatkit.sendwhatmsg_to_instantly(phone, message)
            
            self.message_log.append({
                'to': phone,
                'message': message,
                'time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'sent'
            })
            return True, "Message sent successfully!"
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def send_image(self, phone, image_path, caption=""):
        """Send image via WhatsApp"""
        if not self.enabled:
            return False, "pywhatkit not installed"
        
        try:
            phone = re.sub(r'[^0-9]', '', phone)
            if not phone.startswith('+'):
                phone = '+' + phone
            
            pywhatkit.sendwhats_image(phone, image_path, caption)
            return True, "Image sent successfully!"
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def show_log(self):
        """Display message log"""
        if not self.message_log:
            return "[dim]No messages sent yet.[/dim]"
        
        table = Table(title="WhatsApp Message Log", box=box.ROUNDED)
        table.add_column("Time", style="cyan")
        table.add_column("To", style="green")
        table.add_column("Message", style="white", max_width=40)
        table.add_column("Status", style="yellow")
        
        for entry in self.message_log[-10:]:  # Show last 10
            table.add_row(
                entry['time'],
                entry['to'],
                entry['message'][:40] + "..." if len(entry['message']) > 40 else entry['message'],
                entry['status']
            )
        return table


class UtilityTools:
    """Various utility tools"""
    
    @staticmethod
    def calculator(expression):
        """Calculate mathematical expression"""
        try:
            # Safe evaluation - only allow math operations
            allowed_chars = set('0123456789+-*/().^% ')
            if not all(c in allowed_chars for c in expression):
                return "❌ Invalid characters in expression"
            
            # Replace ^ with ** for exponentiation
            expression = expression.replace('^', '**')
            result = eval(expression)
            return f"🧮 Result: [bold green]{result}[/bold green]"
        except Exception as e:
            return f"❌ Calculation error: {str(e)}"
    
    @staticmethod
    def generate_password(length=12):
        """Generate secure password"""
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(random.choice(chars) for _ in range(length))
        return password
    
    @staticmethod
    def generate_qr(data, filename="qrcode.png"):
        """Generate QR code"""
        if not QR_AVAILABLE:
            return None, "qrcode module not installed. Run: pip install qrcode[pil]"
        
        try:
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            img.save(filename)
            return True, f"QR code saved as {filename}"
        except Exception as e:
            return False, str(e)
    
    @staticmethod
    def get_weather(city):
        """Get weather info (using wttr.in API)"""
        try:
            url = f"https://wttr.in/{quote(city)}?format=3"
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                return f"🌤️ Weather in {city}: {response.text}"
            return "⚠️ Could not fetch weather data"
        except:
            return "⚠️ Weather service unavailable"
    
    @staticmethod
    def convert_currency(amount, from_curr, to_curr):
        """Currency conversion (using free API)"""
        try:
            # Using a free exchange rate API
            url = f"https://api.exchangerate-api.com/v4/latest/{from_curr.upper()}"
            response = requests.get(url, timeout=5)
            data = response.json()
            
            if 'rates' in data and to_curr.upper() in data['rates']:
                rate = data['rates'][to_curr.upper()]
                result = amount * rate
                return f"💱 [bold green]{amount} {from_curr.upper()} = {result:.2f} {to_curr.upper()}[/bold green]"
            return "⚠️ Currency not found"
        except:
            return "⚠️ Conversion service unavailable"
    
    @staticmethod
    def search_wikipedia(query):
        """Search Wikipedia"""
        if not WIKIPEDIA_AVAILABLE:
            return "wikipedia module not installed. Run: pip install wikipedia"
        
        try:
            result = wikipedia.summary(query, sentences=3)
            return f"📚 Wikipedia:\n{result}"
        except wikipedia.exceptions.DisambiguationError as e:
            return f"⚠️ Multiple results found. Be more specific. Options: {', '.join(e.options[:5])}"
        except wikipedia.exceptions.PageError:
            return "⚠️ Page not found"
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    @staticmethod
    def google_search(query, num_results=5):
        """Perform Google search"""
        if not GOOGLE_AVAILABLE:
            return "googlesearch-python not installed. Run: pip install googlesearch-python"
        
        try:
            results = list(search(query, num_results=num_results))
            output = "🔍 Search Results:\n\n"
            for i, result in enumerate(results, 1):
                output += f"{i}. {result}\n"
            return output
        except Exception as e:
            return f"❌ Search error: {str(e)}"
    
    @staticmethod
    def get_system_info():
        """Get system information"""
        info = f"""
[bold cyan]🖥️ System Information[/bold cyan]

Operating System: [bold]{platform.system()} {platform.release()}[/bold]
Processor: [bold]{platform.processor()}[/bold]
Architecture: [bold]{platform.architecture()[0]}[/bold]
Python Version: [bold]{platform.python_version()}[/bold]
Machine: [bold]{platform.machine()}[/bold]
Node Name: [bold]{platform.node()}[/bold]
        """
        return info
    
    @staticmethod
    def organize_files(directory="."):
        """Organize files by extension"""
        try:
            path = Path(directory)
            files = [f for f in path.iterdir() if f.is_file()]
            
            organized = {}
            for file in files:
                ext = file.suffix.lower() or "no_extension"
                if ext not in organized:
                    organized[ext] = []
                organized[ext].append(file)
            
            # Create directories and move files
            for ext, file_list in organized.items():
                folder_name = ext[1:] if ext.startswith('.') else ext
                folder_path = path / folder_name
                folder_path.mkdir(exist_ok=True)
                
                for file in file_list:
                    try:
                        file.rename(folder_path / file.name)
                    except:
                        pass
            
            return f"✅ Organized {len(files)} files into {len(organized)} folders"
        except Exception as e:
            return f"❌ Error organizing files: {str(e)}"


def show_help():
    """Display help menu"""
    help_text = """
[bold cyan]📖 AVAILABLE COMMANDS[/bold cyan]

[bold green]AI Chat Commands:[/bold green]
  /chat [message]  - Start chatting with AI
  /models          - Show available AI models
  /clear           - Clear chat history
  
[bold yellow]WhatsApp Commands (PREMIUM):[/bold yellow]
  /whatsapp        - WhatsApp menu
  /wasend          - Send WhatsApp message
  /walog           - View message log
  
[bold blue]Utility Commands:[/bold blue]
  /calc [expr]     - Calculator (e.g., /calc 5+5)
  /weather [city]  - Get weather info
  /convert         - Currency converter
  /qr [data]       - Generate QR code
  /password [len]  - Generate password
  
[bold magenta]Info Commands:[/bold magenta]
  /wiki [query]    - Wikipedia search
  /search [query]  - Google search
  /define [word]   - Dictionary lookup
  
[bold white]System Commands:[/bold white]
  /sysinfo         - System information
  /organize        - Organize files by type
  
[bold cyan]Premium Commands:[/bold cyan]
  /premium         - Show premium info
  /verify          - Verify premium code
  
[bold red]General Commands:[/bold red]
  /help            - Show this help
  /menu            - Show main menu
  /about           - About this bot
  /exit            - Exit program
    """
    print(Panel.fit(help_text, border_style="bright_cyan", title="[bold]📚 HELP MENU[/bold]"))


def show_menu():
    """Display main menu"""
    menu_text = """
[bold cyan]🎯 MAIN MENU[/bold cyan]

[1] 🤖 AI Chat - Chat with DeepSeek AI
[2] 💬 WhatsApp Bot (Premium) - Send WhatsApp messages
[3] 🛠️ Utilities - Calculator, QR, Password generator
[4] 📚 Information - Wikipedia, News, Search
[5] ⚙️ System Tools - System info, File organizer
[6] 💎 Premium - Upgrade to premium
[7] ❓ Help - Show all commands
[8] 🚪 Exit - Close application

[dim]Type command directly or enter number[/dim]
    """
    print(Panel.fit(menu_text, border_style="bright_green", title="[bold]🎯 MENU[/bold]"))


def show_models(ai_handler):
    """Display available AI models"""
    print("\n[bold yellow]═══════════════════════════════════════[/bold yellow]")
    print("[bold bright_white]       📋 AVAILABLE AI MODELS        [/bold bright_white]")
    print("[bold yellow]═══════════════════════════════════════[/bold yellow]\n")
    
    table = Table(
        show_header=True, 
        box=box.DOUBLE_EDGE, 
        border_style="bright_blue",
        header_style="bold bright_yellow"
    )
    table.add_column("№", style="bold cyan", justify="center", width=5)
    table.add_column("🤖 Model Name", style="bright_white", width=35)
    table.add_column("Status", style="green", justify="center", width=10)
    
    for i, m in enumerate(MODELS, 1):
        status = "✅ Ready"
        table.add_row(f"{i}", m, status)
    
    console.print(table)
    
    choice = Prompt.ask(
        "\n[bold bright_green]👉 Select Model Number (or press Enter to keep current)[/bold bright_green]",
        default=""
    )
    
    if choice.strip():
        try:
            choice_num = int(choice)
            if 1 <= choice_num <= len(MODELS):
                ai_handler.set_model(MODELS[choice_num - 1])
                print(f"\n[bold green]✅ Model changed to:[/bold green] [black on bright_cyan] {ai_handler.model} [/black on bright_cyan]\n")
            else:
                print("[bold red]❌ Invalid selection![/bold red]")
        except:
            print("[bold red]❌ Please enter a valid number![/bold red]")


def whatsapp_menu(whatsapp_bot, config):
    """WhatsApp bot menu"""
    if not check_premium_status(config):
        return
    
    if not PYWHATKIT_AVAILABLE:
        print("\n[bold red]❌ WhatsApp module not installed![/bold red]")
        print("[bold yellow]Run: pip install pywhatkit[/bold yellow]\n")
        return
    
    while True:
        wa_menu = """
[bold cyan]💬 WHATSAPP BOT MENU[/bold cyan]

[1] 📤 Send Message
[2] 🖼️ Send Image
[3] 📋 View Message Log
[4] ℹ️ Status Check
[5] 🔙 Back to Main Menu
        """
        print(Panel.fit(wa_menu, border_style="bright_green"))
        
        choice = Prompt.ask("[bold cyan]Select option[/bold cyan]", default="5")
        
        if choice == "1":
            phone = Prompt.ask("[bold yellow]Enter phone number (with country code, e.g., +234...)[/bold yellow]")
            message = Prompt.ask("[bold yellow]Enter message[/bold yellow]")
            
            schedule = Confirm.ask("[bold cyan]Schedule for later?[/bold cyan]", default=False)
            
            if schedule:
                hour = int(Prompt.ask("[bold yellow]Hour (24-hour format)[/bold yellow]"))
                minute = int(Prompt.ask("[bold yellow]Minute[/bold yellow]"))
                success, msg = whatsapp_bot.send_message(phone, message, (hour, minute))
            else:
                success, msg = whatsapp_bot.send_message(phone, message)
            
            if success:
                print(f"[bold green]✅ {msg}[/bold green]")
            else:
                print(f"[bold red]❌ {msg}[/bold red]")
        
        elif choice == "2":
            phone = Prompt.ask("[bold yellow]Enter phone number[/bold yellow]")
            image_path = Prompt.ask("[bold yellow]Enter image path[/bold yellow]")
            caption = Prompt.ask("[bold yellow]Enter caption (optional)[/bold yellow]", default="")
            
            success, msg = whatsapp_bot.send_image(phone, image_path, caption)
            if success:
                print(f"[bold green]✅ {msg}[/bold green]")
            else:
                print(f"[bold red]❌ {msg}[/bold red]")
        
        elif choice == "3":
            print(whatsapp_bot.show_log())
        
        elif choice == "4":
            print(whatsapp_bot.check_status())
        
        elif choice == "5":
            break


def utilities_menu(utilities):
    """Utilities submenu"""
    while True:
        util_menu = """
[bold cyan]🛠️ UTILITIES MENU[/bold cyan]

[1] 🧮 Calculator
[2] 🌤️ Weather Check
[3] 💱 Currency Converter
[4] 📱 QR Code Generator
[5] 🔐 Password Generator
[6] 🔙 Back to Main Menu
        """
        print(Panel.fit(util_menu, border_style="bright_blue"))
        
        choice = Prompt.ask("[bold cyan]Select option[/bold cyan]", default="6")
        
        if choice == "1":
            expr = Prompt.ask("[bold yellow]Enter expression (e.g., 5+5*2)[/bold yellow]")
            print(utilities.calculator(expr))
        
        elif choice == "2":
            city = Prompt.ask("[bold yellow]Enter city name[/bold yellow]")
            print(utilities.get_weather(city))
        
        elif choice == "3":
            amount = float(Prompt.ask("[bold yellow]Amount[/bold yellow]"))
            from_curr = Prompt.ask("[bold yellow]From currency (e.g., USD)[/bold yellow]")
            to_curr = Prompt.ask("[bold yellow]To currency (e.g., NGN)[/bold yellow]")
            print(utilities.convert_currency(amount, from_curr, to_curr))
        
        elif choice == "4":
            data = Prompt.ask("[bold yellow]Enter data for QR code[/bold yellow]")
            filename = Prompt.ask("[bold yellow]Filename[/bold yellow]", default="qrcode.png")
            success, msg = utilities.generate_qr(data, filename)
            if success:
                print(f"[bold green]✅ {msg}[/bold green]")
            else:
                print(f"[bold red]❌ {msg}[/bold red]")
        
        elif choice == "5":
            length = int(Prompt.ask("[bold yellow]Password length[/bold yellow]", default="12"))
            password = utilities.generate_password(length)
            print(f"[bold green]🔐 Generated Password: [black on white]{password}[/black on white][/bold green]")
        
        elif choice == "6":
            break


def info_menu(utilities):
    """Information submenu"""
    while True:
        info_menu_text = """
[bold cyan]📚 INFORMATION MENU[/bold cyan]

[1] 📖 Wikipedia Search
[2] 🔍 Google Search
[3] 📰 Get News (coming soon)
[4] 📖 Dictionary (coming soon)
[5] 🔙 Back to Main Menu
        """
        print(Panel.fit(info_menu_text, border_style="bright_magenta"))
        
        choice = Prompt.ask("[bold cyan]Select option[/bold cyan]", default="5")
        
        if choice == "1":
            query = Prompt.ask("[bold yellow]Enter search query[/bold yellow]")
            print(utilities.search_wikipedia(query))
        
        elif choice == "2":
            query = Prompt.ask("[bold yellow]Enter search query[/bold yellow]")
            print(utilities.google_search(query))
        
        elif choice == "3":
            print("[bold yellow]📰 News feature coming in next update![/bold yellow]")
        
        elif choice == "4":
            print("[bold yellow]📖 Dictionary feature coming in next update![/bold yellow]")
        
        elif choice == "5":
            break


def system_menu(utilities):
    """System tools submenu"""
    while True:
        sys_menu = """
[bold cyan]⚙️ SYSTEM TOOLS MENU[/bold cyan]

[1] 🖥️ System Information
[2] 📁 Organize Files
[3] 💾 Disk Usage (coming soon)
[4] 🔙 Back to Main Menu
        """
        print(Panel.fit(sys_menu, border_style="bright_white"))
        
        choice = Prompt.ask("[bold cyan]Select option[/bold cyan]", default="4")
        
        if choice == "1":
            print(utilities.get_system_info())
        
        elif choice == "2":
            directory = Prompt.ask("[bold yellow]Enter directory path[/bold yellow]", default=".")
            print(utilities.organize_files(directory))
        
        elif choice == "3":
            print("[bold yellow]💾 Disk usage feature coming soon![/bold yellow]")
        
        elif choice == "4":
            break


def about():
    """Display about information"""
    about_text = f"""
[bold cyan]🤖 ABOUT DEEPSEEK AI ULTIMATE[/bold cyan]

Version: [bold]2.0 Ultimate[/bold]
Developer: [bold green]{DEVELOPER}[/bold green]
Telegram Channel: [bold cyan]{TELEGRAM_CHANNEL}[/bold cyan]

[bold yellow]Features:[/bold yellow]
✅ Advanced AI Chat with DeepSeek Models
✅ WhatsApp Bot Integration (Premium)
✅ Utility Tools (Calculator, QR, Password)
✅ Information Tools (Wikipedia, Search)
✅ System Tools (File Organizer)

[bold magenta]Premium Features:[/bold magenta]
💎 WhatsApp Bot Integration
💎 Unlimited AI Messages
💎 Priority Support
💎 Advanced Tools

[bold green]Support & Updates:[/bold green]
Join our Telegram channel for updates, support, and premium activation!
{TELEGRAM_URL}

[bold red]Payment for Premium:[/bold red]
Amount: {PAYMENT_DETAILS['amount']}
Account: {PAYMENT_DETAILS['account_number']}
Bank: {PAYMENT_DETAILS['bank']}
Name: {PAYMENT_DETAILS['account_name']}

[dim]© 2024 DeepSeek AI Ultimate. All rights reserved.[/dim]
    """
    print(Panel.fit(about_text, border_style="bright_cyan", title="[bold]ℹ️ ABOUT[/bold]"))


def main():
    """Main application loop"""
    # Load configuration
    config = load_config()
    
    # Display banner
    display_banner()
    
    # First run - redirect to Telegram
    if config.get("first_run", True):
        redirect_to_telegram()
        config["first_run"] = False
        save_config(config)
    
    # Initialize handlers
    ai_handler = DeepSeekAI()
    whatsapp_bot = WhatsAppBot()
    utilities = UtilityTools()
    
    # Show initial loading
    with console.status("[bold bright_yellow]🚀 Initializing systems...", spinner="dots"):
        time.sleep(1)
    
    print("\n[bold green]✅ All systems ready![/bold green]\n")
    
    # Show premium status
    if config.get("premium", False):
        print("[bold cyan]💎 PREMIUM USER - All features unlocked![/bold cyan]\n")
    else:
        print("[bold yellow]⭐ Free Version - Upgrade to Premium for WhatsApp Bot![/bold yellow]")
        print("[dim]Type /premium for more info[/dim]\n")
    
    # Main loop
    while True:
        show_menu()
        
        user_input = Prompt.ask("[bold bright_cyan]👉 Enter command[/bold bright_cyan]").strip()
        
        if not user_input:
            continue
        
        # Parse command
        parts = user_input.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        
        # Handle numbered menu selection
        if command.isdigit():
            menu_map = {
                "1": "/chat",
                "2": "/whatsapp",
                "3": "/utils",
                "4": "/info",
                "5": "/system",
                "6": "/premium",
                "7": "/help",
                "8": "/exit"
            }
            command = menu_map.get(command, command)
        
        # Process commands
        if command in ["/exit", "/quit", "exit", "quit"]:
            print(Panel.fit(
                "[bold bright_yellow]👋 Thanks for using DeepSeek AI Ultimate!\n"
                "🔔 Don't forget to join @CyberVault01 on Telegram![/bold bright_yellow]",
                border_style="bright_magenta",
                title="[bold red]GOODBYE[/bold red]"
            ))
            break
        
        elif command in ["/help", "help", "?"]:
            show_help()
        
        elif command in ["/menu", "menu"]:
            continue
        
        elif command == "/about":
            about()
        
        elif command == "/chat":
            # Direct chat mode
            if args:
                with console.status("[bold bright_yellow]🧠 AI is thinking...", spinner="bouncingBall"):
                    response = ai_handler.chat(args)
                print(Panel(
                    response,
                    border_style="bright_magenta",
                    title=f"[bold green]🤖 {ai_handler.model}[/bold green]"
                ))
            else:
                # Interactive chat mode
                print("\n[bold cyan]💬 Interactive Chat Mode - Type 'back' to return to menu[/bold cyan]\n")
                while True:
                    msg = Prompt.ask("[bold bright_cyan]📝 You[/bold bright_cyan]").strip()
                    if msg.lower() in ["back", "exit", "quit"]:
                        break
                    if not msg:
                        continue
                    
                    with console.status("[bold bright_yellow]🧠 AI is thinking...", spinner="bouncingBall"):
                        response = ai_handler.chat(msg)
                    
                    print(Panel(
                        response,
                        border_style="bright_magenta",
                        title=f"[bold green]🤖 {ai_handler.model}[/bold green]",
                        subtitle="[bold cyan]Powered by DeepSeek AI[/bold cyan]"
                    ))
        
        elif command == "/models":
            show_models(ai_handler)
        
        elif command == "/clear":
            os.system('cls' if os.name == 'nt' else 'clear')
            display_banner()
        
        elif command in ["/whatsapp", "/wa", "2"]:
            whatsapp_menu(whatsapp_bot, config)
        
        elif command == "/wastatus":
            print(whatsapp_bot.check_status())
        
        elif command == "/walog":
            if check_premium_status(config):
                print(whatsapp_bot.show_log())
        
        elif command in ["/utils", "/utilities", "3"]:
            utilities_menu(utilities)
        
        elif command in ["/info", "/information", "4"]:
            info_menu(utilities)
        
        elif command in ["/system", "/sys", "5"]:
            system_menu(utilities)
        
        elif command in ["/premium", "/upgrade", "6"]:
            show_payment_info()
            if not config.get("premium", False):
                if Confirm.ask("[bold cyan]Do you have a premium code?[/bold cyan]", default=False):
                    verify_premium_code(config)
        
        elif command == "/verify":
            verify_premium_code(config)
        
        elif command == "/calc":
            if args:
                print(utilities.calculator(args))
            else:
                expr = Prompt.ask("[bold yellow]Enter expression[/bold yellow]")
                print(utilities.calculator(expr))
        
        elif command == "/weather":
            if args:
                print(utilities.get_weather(args))
            else:
                city = Prompt.ask("[bold yellow]Enter city name[/bold yellow]")
                print(utilities.get_weather(city))
        
        elif command == "/convert":
            amount = float(Prompt.ask("[bold yellow]Amount[/bold yellow]"))
            from_curr = Prompt.ask("[bold yellow]From currency (e.g., USD)[/bold yellow]")
            to_curr = Prompt.ask("[bold yellow]To currency (e.g., NGN)[/bold yellow]")
            print(utilities.convert_currency(amount, from_curr, to_curr))
        
        elif command == "/qr":
            if args:
                success, msg = utilities.generate_qr(args)
                print(f"[bold {'green' if success else 'red'}]{msg}[/bold {'green' if success else 'red'}]")
            else:
                data = Prompt.ask("[bold yellow]Enter data for QR code[/bold yellow]")
                success, msg = utilities.generate_qr(data)
                print(f"[bold {'green' if success else 'red'}]{msg}[/bold {'green' if success else 'red'}]")
        
        elif command == "/password":
            length = int(args) if args.isdigit() else 12
            password = utilities.generate_password(length)
            print(f"[bold green]🔐 Generated Password: [black on white]{password}[/black on white][/bold green]")
        
        elif command == "/wiki":
            if args:
                print(utilities.search_wikipedia(args))
            else:
                query = Prompt.ask("[bold yellow]Enter search query[/bold yellow]")
                print(utilities.search_wikipedia(query))
        
        elif command == "/search":
            if args:
                print(utilities.google_search(args))
            else:
                query = Prompt.ask("[bold yellow]Enter search query[/bold yellow]")
                print(utilities.google_search(query))
        
        elif command == "/sysinfo":
            print(utilities.get_system_info())
        
        elif command == "/organize":
            directory = args if args else "."
            print(utilities.organize_files(directory))
        
        elif command == "/support":
            print(f"\n[bold cyan]📞 Support Channels:[/bold cyan]")
            print(f"Telegram Channel: [bold]{TELEGRAM_CHANNEL}[/bold]")
            print(f"Telegram URL: [bold]{TELEGRAM_URL}[/bold]")
            print(f"Developer: [bold]{DEVELOPER}[/bold]\n")
        
        else:
            # If not a command, treat as chat message
            with console.status("[bold bright_yellow]🧠 AI is thinking...", spinner="bouncingBall"):
                response = ai_handler.chat(user_input)
            print(Panel(
                response,
                border_style="bright_magenta",
                title=f"[bold green]🤖 {ai_handler.model}[/bold green]"
            ))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[bold yellow]👋 Goodbye! Thanks for using DeepSeek AI Ultimate![/bold yellow]")
        sys.exit(0)
    except Exception as e:
        print(f"\n[bold red]❌ Fatal Error: {e}[/bold red]")
        sys.exit(1)
